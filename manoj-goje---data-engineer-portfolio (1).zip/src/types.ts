export interface SkillItem {
  name: string;
  category: 'cloud' | 'languages' | 'mlops' | 'data_eng';
  iconKey: string;
  experienceLevel?: string;
  description: string;
  brandColor?: string;
}

export interface PipelineNodeData {
  id: string;
  title: string;
  subtitle?: string;
  iconKey: string;
  layer?: 'source' | 'bronze' | 'silver' | 'gold' | 'serving' | 'ingest' | 'stream' | 'storage';
  badgeColor?: string;
  details?: {
    format?: string;
    engine?: string;
    sla?: string;
    partition?: string;
    purpose?: string;
  };
}

export interface PipelineEdgeData {
  label: string;
  sublabel?: string;
}

export interface ProjectData {
  id: string;
  title: string;
  subtitle: string;
  tagline: string;
  techStack: { name: string; iconKey: string }[];
  bullets: string[];
  metrics: { label: string; value: string }[];
  flowNodes: PipelineNodeData[];
  flowEdges: PipelineEdgeData[];
}

export interface ExperienceData {
  company: string;
  role: string;
  period: string;
  location: string;
  summary: string;
  bullets: string[];
  skills: string[];
  metrics: { label: string; value: string }[];
}

export interface CertificationData {
  name: string;
  code: string;
  issuer: 'Microsoft' | 'Databricks' | 'Oracle' | string;
  issueDate: string;
  status: string;
  credentialUrl?: string;
  description: string;
  iconKey: string;
  accentColor: string;
}

export interface EducationData {
  degree: string;
  field: string;
  institution: string;
  location: string;
  period: string;
  highlights: string[];
}

export interface LeadershipItem {
  id: string;
  title: string;
  role: string;
  metric: string;
  tag: string;
  description: string;
  highlights: string[];
  iconKey: 'trophy' | 'users' | 'code' | 'zap';
}

import { jsPDF } from 'jspdf';

/**
 * Creates the exact jsPDF document corresponding 1:1 with the user's provided resume PDF:
 * - A4 page size (595.28 pt x 841.89 pt)
 * - Optimized line spacing and typography filling the A4 page smoothly from top to bottom
 * - Zero bottom blank space while fitting strictly on 1 single page
 * - Times New Roman serif font, clean alignment, and bullet indentation
 */
export function createResumePDFDoc(): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 595.28 pt
  const margin = 38;
  const contentWidth = pageWidth - margin * 2;
  let y = 46;

  // 1. NAME HEADER (Centred, Bold, Serif)
  doc.setFont('times', 'bold');
  doc.setFontSize(23.5);
  doc.setTextColor(0, 0, 0);
  doc.text('MANOJ GOJE', pageWidth / 2, y, { align: 'center' });

  // Contact line with em-dashes
  y += 18;
  doc.setFont('times', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(30, 30, 30);
  const contactText = 'Pune, Maharashtra, India  —  8805861929  —  manojgoje02@gmail.com  —  linkedin.com/in/manoj-goje';
  doc.text(contactText, pageWidth / 2, y, { align: 'center' });

  // Section Header Drawer Helper (with exact clean underline)
  const drawSectionHeader = (title: string) => {
    y += 19;
    doc.setFont('times', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text(title, margin, y);
    y += 3.5;
    doc.setDrawColor(40, 40, 40);
    doc.setLineWidth(0.65);
    doc.line(margin, y, pageWidth - margin, y);
    y += 12.5;
  };

  // Helper for rendering multi-line text
  const renderParagraph = (text: string) => {
    doc.setFont('times', 'normal');
    doc.setFontSize(9.8);
    doc.setTextColor(20, 20, 20);
    const lines = doc.splitTextToSize(text, contentWidth);
    doc.text(lines, margin, y);
    y += lines.length * 12.6 + 2;
  };

  // Helper for rendering bullet points with proper hanging indentation
  const renderBullet = (text: string, isLast = false) => {
    doc.setFont('times', 'normal');
    doc.setFontSize(9.6);
    doc.setTextColor(20, 20, 20);
    doc.text('•', margin + 2, y);
    const lines = doc.splitTextToSize(text, contentWidth - 14);
    doc.text(lines, margin + 14, y);
    y += lines.length * 12.4 + (isLast ? 2 : 4);
  };

  // --- SECTION: Professional Summary ---
  drawSectionHeader('Professional Summary');
  renderParagraph(
    'Data Operations Engineer – GIS Mapping with hands-on experience monitoring, validating, and maintaining large-scale geospatial and structured/semi-structured data pipelines. Skilled in incident diagnosis, root-cause analysis, and SLA-driven data quality resolution across enterprise mapping and analytics systems. Proficient in Azure cloud services, PySpark, and SQL for scalable data operations; experienced with data validation, feature engineering, and pipeline health monitoring on enterprise datasets. DP-203, AZ-104, and Databricks certified; adept at communicating operational outcomes to cross-functional stakeholders while adhering to data governance and compliance standards.'
  );

  // --- SECTION: Technical Skills ---
  drawSectionHeader('Technical Skills');
  
  const renderSkillRow = (label: string, value: string) => {
    doc.setFont('times', 'bold');
    doc.setFontSize(9.7);
    doc.setTextColor(0, 0, 0);
    doc.text(label, margin, y);
    doc.setFont('times', 'normal');
    doc.setTextColor(20, 20, 20);
    const labelWidth = doc.getTextWidth(label) + 3.5;
    const valueLines = doc.splitTextToSize(value, contentWidth - labelWidth);
    doc.text(valueLines, margin + labelWidth, y);
    y += valueLines.length * 12.2 + 2.4;
  };

  renderSkillRow('ML Frameworks & Libraries: ', 'Python, Scikit-learn, PySpark, SQL, NLP, Predictive Modeling');
  renderSkillRow('Cloud Platforms: ', 'Microsoft Azure (ADF, Databricks, ADLS Gen2, Synapse Analytics, Azure SQL DB)');
  renderSkillRow('MLOps & DevOps: ', 'Git, GitHub Actions, CI/CD, Docker, Jupyter, Delta Lake');
  renderSkillRow('Data Engineering: ', 'Feature Engineering, ETL/ELT, Batch & Streaming Pipelines, Data Governance');
  renderSkillRow('Concepts: ', 'Machine Learning, Deep Learning Fundamentals, Incident Management, Root Cause Analysis');

  // --- SECTION: Professional Experience ---
  drawSectionHeader('Professional Experience');
  doc.setFont('times', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(0, 0, 0);
  doc.text('Cognizant Technology Solutions', margin, y);
  doc.setFont('times', 'normal');
  doc.setFontSize(10);
  doc.text('Pune, Maharashtra', pageWidth - margin, y, { align: 'right' });
  y += 13;

  doc.setFont('times', 'italic');
  doc.setFontSize(9.8);
  doc.setTextColor(30, 30, 30);
  doc.text('Data Operations Engineer – GIS & Mapping', margin, y);
  doc.setFont('times', 'normal');
  doc.text('July 2025 – Present', pageWidth - margin, y, { align: 'right' });
  y += 12.5;

  renderBullet('Processed and validated large-scale clinical and geospatial datasets containing millions of records using Python and SQL pipelines, achieving 99%+ data accuracy in compliance with defined SLA standards across enterprise systems.');
  renderBullet('Engineered end-to-end data cleansing, normalization, and feature validation pipelines across multiple enterprise databases, reducing data discrepancy incidents by 30% and improving downstream model-readiness of structured datasets.');
  renderBullet('Collaborated with cross-functional analytics teams to translate business requirements into scalable data solutions, reducing average data quality resolution turnaround by 40% and improving pipeline reliability for reporting stakeholders.', true);

  // --- SECTION: Key Projects ---
  drawSectionHeader('Key Projects');
  
  // Project 1
  doc.setFont('times', 'bold');
  doc.setFontSize(10.2);
  doc.setTextColor(0, 0, 0);
  doc.text('ML-Ready Data Pipeline with Feature Engineering on Azure (Medallion Architecture)', margin, y);
  y += 12.5;

  doc.setFont('times', 'italic');
  doc.setFontSize(9.4);
  doc.setTextColor(40, 40, 40);
  doc.text('Tech Stack: Azure Data Factory — ADLS Gen2 — Azure Databricks — PySpark — Delta Lake — Synapse Analytics — Python', margin, y);
  y += 12;

  renderBullet('Architected a multi-layer Medallion (Bronze/Silver/Gold) data pipeline ingesting structured CSV/JSON datasets via Azure Data Factory into ADLS Gen2, enabling feature-ready datasets for downstream ML model training at scale.');
  renderBullet('Implemented PySpark-based feature engineering and data transformation jobs in Azure Databricks, applying statistical normalization and schema evolution on Delta Lake tables to produce analytics-ready training datasets, reducing data prep time by 50%.');
  renderBullet('Built Gold-layer Synapse Analytics SQL views for BI and model evaluation reporting; deployed CI/CD automation via GitHub Actions, cutting pipeline release cycles from days to under 2 hours across dev and production environments.', true);

  y += 4.5;

  // Project 2
  doc.setFont('times', 'bold');
  doc.setFontSize(10.2);
  doc.setTextColor(0, 0, 0);
  doc.text('Real-Time Predictive Event Streaming Pipeline — Azure Event Hub + Databricks', margin, y);
  y += 12.5;

  doc.setFont('times', 'italic');
  doc.setFontSize(9.4);
  doc.setTextColor(40, 40, 40);
  doc.text('Tech Stack: Azure Event Hub — Azure Databricks — PySpark Structured Streaming — Delta Lake — Azure SQL DB', margin, y);
  y += 12;

  renderBullet('Designed and deployed a real-time ML-ready data streaming pipeline using Azure Event Hub and Databricks Structured Streaming, enabling exactly-once semantic ingestion of event data into Delta Lake for continuous model inference workflows.');
  renderBullet('Optimized checkpoint management and trigger intervals to achieve low-latency event processing, reducing end-to-end streaming latency by 35% and improving downstream dashboarding throughput for clinical analytics use cases.', true);

  // --- SECTION: Certifications ---
  drawSectionHeader('Certifications');
  renderBullet('Microsoft Certified: Azure Administrator Associate AZ-104 — Microsoft');
  renderBullet('Microsoft Certified: Azure Data Engineer Associate (DP-203) — Microsoft');
  renderBullet('Databricks Certified Data Engineer Associate — Databricks', true);

  // --- SECTION: Education ---
  drawSectionHeader('Education');
  doc.setFont('times', 'bold');
  doc.setFontSize(10.2);
  doc.setTextColor(0, 0, 0);
  doc.text('Bachelor of Technology (B.Tech) — Computer Science and Engineering', margin, y);
  doc.setFont('times', 'normal');
  doc.setFontSize(9.8);
  doc.text('August 2020 – July 2024', pageWidth - margin, y, { align: 'right' });
  y += 13;

  doc.setFont('times', 'normal');
  doc.setFontSize(9.6);
  doc.text('Shreeyash College of Engineering and Technology, Aurangabad', margin, y);

  return doc;
}

/**
 * Secure download handler:
 * Direct fetch from /resume.pdf (or /Manoj_Goje_Resume.pdf in public folder), converts to blob,
 * and forces the browser to trigger an immediate download rather than opening/navigating.
 */
export async function downloadResumeSecure(filename = 'Manoj_Goje_Resume.pdf'): Promise<void> {
  try {
    // Attempt to fetch direct static PDF file from public directory
    const response = await fetch('/resume.pdf');
    if (response.ok) {
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }));
      
      const link = document.createElement('a');
      link.href = blobUrl;
      link.setAttribute('download', filename);
      link.setAttribute('rel', 'noopener noreferrer');
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(blobUrl);
      }, 500);
      return;
    }
  } catch (err) {
    console.warn('Direct static fetch failed, generating fresh PDF doc blob...', err);
  }

  // Fallback: Generate the exact PDF directly from jsPDF and force immediate download
  try {
    const doc = createResumePDFDoc();
    const pdfBlob = doc.output('blob');
    const blobUrl = window.URL.createObjectURL(pdfBlob);

    const link = document.createElement('a');
    link.href = blobUrl;
    link.setAttribute('download', filename);
    link.setAttribute('rel', 'noopener noreferrer');
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    }, 500);
  } catch (err) {
    const doc = createResumePDFDoc();
    doc.save(filename);
  }
}

/**
 * Backward-compatible download wrapper
 */
export function downloadResumePDF() {
  downloadResumeSecure('Manoj_Goje_Resume.pdf');
}

/**
 * Prints the resume directly with robust cross-browser and iframe compatibility
 */
export function printResumePDF() {
  const doc = createResumePDFDoc();
  
  try {
    // Generate auto-print PDF blob
    doc.autoPrint();
    const blob = doc.output('blob');
    const blobUrl = URL.createObjectURL(blob);

    // Create a hidden iframe to trigger print
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';
    iframe.src = blobUrl;
    document.body.appendChild(iframe);

    iframe.onload = () => {
      setTimeout(() => {
        try {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
        } catch {
          window.print();
        }
      }, 150);
    };

    // Clean up iframe after 60 seconds
    setTimeout(() => {
      if (document.body.contains(iframe)) {
        document.body.removeChild(iframe);
      }
    }, 60000);
  } catch {
    window.print();
  }
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { TechSkills } from './components/TechSkills';
import { Experience } from './components/Experience';
import { Projects } from './components/Projects';
import { Leadership } from './components/Leadership';
import { Certifications } from './components/Certifications';
import { Education } from './components/Education';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ResumeModal } from './components/ResumeModal';

function MainApp() {
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const { darkMode } = useTheme();

  return (
    <div className={`min-h-screen font-sans selection:bg-[#0078D4] selection:text-white transition-colors duration-200 ${
      darkMode ? 'bg-[#080f1e] text-slate-100' : 'bg-[#f4f8fc] text-slate-800'
    }`}>
      
      {/* Authentic Azure Portal Global Header & Ribbon Navigation with SINGLE Theme Toggle */}
      <Navbar
        onOpenResume={() => setIsResumeOpen(true)}
      />

      {/* Main Azure Portal Workspace / Resource Blades */}
      <main className="relative overflow-hidden pt-20">
        {/* 1. Hero / Portal Dashboard Overview */}
        <Hero onOpenResume={() => setIsResumeOpen(true)} />

        {/* 2. About / Executive Summary Blade */}
        <About />

        {/* 3. Technical Skills (Azure Resource Catalog) */}
        <TechSkills />

        {/* 4. Professional Experience (Azure Activity Log & SLA Trackers) */}
        <Experience />

        {/* 5. Key Projects (Azure Data Factory & Medallion Pipeline Monitors) */}
        <Projects darkMode={darkMode} />

        {/* 6. Leadership & Hackathon Achievements */}
        <Leadership />

        {/* 7. Certifications (Azure Advisor & Official Security Credentials) */}
        <Certifications />

        {/* 8. Education & Academic Background */}
        <Education />

        {/* 9. Contact / Support & Troubleshooting Blade (Direct Dispatch) */}
        <Contact />
      </main>

      {/* Footer */}
      <Footer />

      {/* Interactive Resume Modal with Exact Attached PDF Download */}
      <ResumeModal
        isOpen={isResumeOpen}
        onClose={() => setIsResumeOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MainApp />
    </ThemeProvider>
  );
}

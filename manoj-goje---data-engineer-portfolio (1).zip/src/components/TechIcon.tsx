import React from 'react';
import {
  Database,
  Layers,
  Activity,
  Workflow,
  Server,
  FileCode,
  Binary,
  Radio,
  FileJson,
  BarChart3,
  Cpu,
} from 'lucide-react';

interface TechIconProps {
  name: string;
  className?: string;
  size?: number;
}

export const TechIcon: React.FC<TechIconProps> = ({ name, className = 'w-5 h-5', size }) => {
  const normalized = name.toLowerCase().replace(/[\s\-_]/g, '');

  // 1. Python
  if (normalized.includes('python')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" style={{ width: size, height: size }}>
        <path fill="#3776AB" d="M11.914 0C5.836 0 6.223 2.64 6.223 2.64l.006 2.735h5.792v.82H3.89S0 5.76 0 11.914c0 6.155 3.4 5.96 3.4 5.96h2.03v-2.85s-.11-3.4 3.34-3.4h5.75s3.23.05 3.23-3.14V3.14S18.27 0 11.914 0zm-3.2 1.83a1.03 1.03 0 1 1 0 2.06 1.03 1.03 0 0 1 0-2.06z"/>
        <path fill="#FFD43B" d="M12.086 24c6.078 0 5.69-2.64 5.69-2.64l-.005-2.735h-5.793v-.82h8.131s3.89.435 3.89-5.72c0-6.154-3.4-5.96-3.4-5.96h-2.03v2.85s.11 3.4-3.34 3.4H9.479s-3.23-.05-3.23 3.14v5.337S5.73 24 12.086 24zm3.2-1.83a1.03 1.03 0 1 1 0-2.06 1.03 1.03 0 0 1 0 2.06z"/>
      </svg>
    );
  }

  // 2. PySpark / Apache Spark
  if (normalized.includes('pyspark') || normalized.includes('spark') || normalized.includes('apachespark')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <path d="M12.5 2L14 7.5L19.5 9L14 10.5L12.5 16L11 10.5L5.5 9L11 7.5L12.5 2Z" fill="#E25A1C" />
        <path d="M18 14L19 17L22 18L19 19L18 22L17 19L14 18L17 17L18 14Z" fill="#F48024" />
        <path d="M6 14L7 17L10 18L7 19L6 22L5 19L2 18L5 17L6 14Z" fill="#E25A1C" opacity="0.8" />
      </svg>
    );
  }

  // 3. Databricks
  if (normalized.includes('databricks')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" style={{ width: size, height: size }}>
        <path fill="#FF3621" d="M1.378 17.844L12 24l10.622-6.156L12 11.688 1.378 17.844zM12 0L1.378 6.156 12 12.312l10.622-6.156L12 0zm0 6.643L4.17 11.17 12 15.696l7.83-4.526L12 6.643z"/>
      </svg>
    );
  }

  // 4. SQL (Structured Query Language) & Database Engine
  if (normalized === 'sql' || normalized.includes('sqldatabase') || normalized.includes('structuredquery')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <rect width="64" height="64" rx="14" fill="#00758F" fillOpacity="0.15" />
        {/* Top Cylinder */}
        <ellipse cx="32" cy="18" rx="20" ry="7.5" fill="#00758F" stroke="#00BCF2" strokeWidth="2.5" />
        {/* Middle Tier */}
        <path d="M12 18V32C12 36.1421 20.9543 39.5 32 39.5C43.0457 39.5 52 36.1421 52 32V18" stroke="#00BCF2" strokeWidth="2.5" />
        {/* Bottom Tier */}
        <path d="M12 32V46C12 50.1421 20.9543 53.5 32 53.5C43.0457 53.5 52 50.1421 52 46V32" stroke="#00BCF2" strokeWidth="2.5" />
        {/* SQL text badge */}
        <rect x="20" y="27" width="24" height="13" rx="4" fill="#0B132B" stroke="#38BDF8" strokeWidth="1.5" />
        <text x="32" y="36.5" fill="#38BDF8" fontSize="8.5" fontWeight="900" fontFamily="monospace" textAnchor="middle" letterSpacing="0.5">
          SQL
        </text>
      </svg>
    );
  }

  // 4b. PostgreSQL
  if (normalized.includes('postgresql') || normalized.includes('postgres')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <rect width="64" height="64" rx="14" fill="#336791" fillOpacity="0.18" />
        <path
          d="M32 10C21 10 16 17 16 26C16 34 20 40 24 43C23 47 20 50 18 52C23 52 28 49 31 45C33 46 36 46 38 45C45 42 48 35 48 26C48 17 43 10 32 10Z"
          fill="#336791"
          stroke="#41B883"
          strokeWidth="2"
        />
        <circle cx="28" cy="24" r="2.5" fill="#ffffff" />
        <circle cx="38" cy="24" r="2.5" fill="#ffffff" />
        <path d="M26 34C28 37 36 37 38 34" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
      </svg>
    );
  }

  // 5. Docker
  if (normalized.includes('docker')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" style={{ width: size, height: size }}>
        <path fill="#2496ED" d="M13.983 11.078h2.119a.186.186 0 00.186-.185V9.006a.186.186 0 00-.186-.186h-2.119a.185.185 0 00-.185.186v1.887c0 .102.083.185.185.185zm-2.954-5.43h2.118a.186.186 0 00.186-.186V3.574a.186.186 0 00-.186-.185h-2.118a.185.185 0 00-.185.185v1.888c0 .102.082.185.185.185zm0 2.716h2.118a.187.187 0 00.186-.186V6.29a.186.186 0 00-.186-.185h-2.118a.185.185 0 00-.185.185v1.888c0 .102.082.186.185.186zm-2.93 0h2.12a.186.186 0 00.184-.186V6.29a.185.185 0 00-.185-.185H8.1a.185.185 0 00-.185.185v1.888c0 .102.083.186.185.186zm-2.93 0h2.12a.185.185 0 00.184-.186V6.29a.185.185 0 00-.184-.185h-2.12a.185.185 0 00-.185.185v1.888c0 .102.083.186.185.186zm8.814 0h2.119a.186.186 0 00.186-.186V6.29a.186.186 0 00-.186-.185h-2.119a.186.186 0 00-.186.185v1.888c0 .102.083.186.186.186zm-5.884 2.714h2.118a.186.186 0 00.186-.185V9.006a.186.186 0 00-.186-.186h-2.118a.186.186 0 00-.186.186v1.887c0 .102.083.185.186.185zm-2.93 0h2.12a.185.185 0 00.184-.185V9.006a.185.185 0 00-.184-.186h-2.12a.185.185 0 00-.184.186v1.887c0 .102.083.185.185.185zm-2.93 0h2.12a.185.185 0 00.184-.185V9.006a.185.185 0 00-.184-.186h-2.12a.186.186 0 00-.186.186v1.887c0 .102.083.185.186.185zM23.77 10.9c-.31-.4-.954-.535-1.503-.362-.128-.535-.443-.997-.935-1.32-.423-.277-.923-.42-1.446-.42-1.077 0-2.02.6-2.507 1.517H.186A.186.186 0 000 10.5v2.998c0 2.213.914 4.316 2.507 5.798C4.1 20.776 6.22 21.6 8.448 21.6c4.61 0 8.89-2.956 11.233-7.72 1.488-.17 2.68-1.127 3.25-2.518.257-.162.593-.327.84-.462z"/>
      </svg>
    );
  }

  // 6. GitHub Actions / CI/CD
  if (normalized.includes('githubaction') || normalized.includes('githubactions') || normalized.includes('cicd')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" style={{ width: size, height: size }}>
        <path fill="#2088FF" d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>
      </svg>
    );
  }

  // 7. Jupyter
  if (normalized.includes('jupyter')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" style={{ width: size, height: size }}>
        <path fill="#F37626" d="M12 0a6.578 6.578 0 00-6.49 5.56 8.528 8.528 0 0112.98 0A6.578 6.578 0 0012 0zm0 24a6.578 6.578 0 006.49-5.56 8.528 8.528 0 01-12.98 0A6.578 6.578 0 0012 24zm-8.835-9.155a3.46 3.46 0 100-5.69 3.46 3.46 0 000 5.69zm17.67 0a3.46 3.46 0 100-5.69 3.46 3.46 0 000 5.69z"/>
      </svg>
    );
  }

  // 8. Scikit-learn
  if (normalized.includes('scikitlearn') || normalized.includes('sklearn')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="none" style={{ width: size, height: size }}>
        <path fill="#F7931E" d="M12 2L2 7l10 5 10-5-10-5zm0 8.5L4.5 7 12 3.25 19.5 7 12 10.5z"/>
        <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#3499CD" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    );
  }

  // 9. Git
  if (normalized === 'git' || (normalized.includes('git') && !normalized.includes('hub'))) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" style={{ width: size, height: size }}>
        <path fill="#F05032" d="M23.546 10.93L13.067.452a1.5 1.5 0 00-2.124 0L8.83 2.564l3.14 3.141a1.782 1.782 0 011.666 2.378l3.02 3.021a1.78 1.78 0 012.38 1.666 1.785 1.785 0 01-1.786 1.786 1.786 1.786 0 01-1.786-1.786c0-.398.13-.766.35-1.066l-2.82-2.82v5.674c.48.243.82.735.82 1.306a1.785 1.785 0 01-1.786 1.786 1.786 1.786 0 01-1.786-1.786c0-.571.34-1.063.82-1.306V9.014a1.786 1.786 0 01-1.066-.35L6.64 11.484a1.785 1.785 0 01.35 1.066 1.785 1.785 0 01-1.786 1.786 1.785 1.785 0 01-1.786-1.786 1.785 1.785 0 011.786-1.786c.398 0 .766.13 1.066.35l2.82-2.82-3.14-3.14L.452 10.93a1.5 1.5 0 000 2.124L10.93 23.533a1.5 1.5 0 002.124 0l10.492-10.48a1.5 1.5 0 000-2.124z"/>
      </svg>
    );
  }

  // 10. LinkedIn
  if (normalized.includes('linkedin')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" style={{ width: size, height: size }}>
        <path fill="#0A66C2" d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
      </svg>
    );
  }

  // 11. Microsoft Official 4-color Logo
  if (normalized.includes('microsoft') || normalized === 'ms') {
    return (
      <svg className={className} viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <path d="M1 1H10.5V10.5H1V1Z" fill="#F25022"/>
        <path d="M12.5 1H22V10.5H12.5V1Z" fill="#7FBA00"/>
        <path d="M1 12.5H10.5V22H1V12.5Z" fill="#00A4EF"/>
        <path d="M12.5 12.5H22V22H12.5V12.5Z" fill="#FFB900"/>
      </svg>
    );
  }

  // 11b. Oracle Official Red Badge / Agentic AI
  if (normalized.includes('oracle') || normalized.includes('agentic')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <rect width="64" height="64" rx="14" fill="#F80000" fillOpacity="0.16" />
        <path
          d="M20 18H44C51.732 18 58 24.268 58 32C58 39.732 51.732 46 44 46H20C12.268 46 6 39.732 6 32C6 24.268 12.268 18 20 18Z"
          stroke="#F80000"
          strokeWidth="4.5"
        />
        <circle cx="32" cy="32" r="6" fill="#F80000" />
      </svg>
    );
  }

  // 12. Azure Data Factory (ADF)
  if (normalized.includes('datafactory') || normalized.includes('adf')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <rect width="64" height="64" rx="12" fill="#0078D4" fillOpacity="0.18" />
        <path d="M18 20C18 17.7909 19.7909 16 22 16H42C44.2091 16 46 17.7909 46 20V44C46 46.2091 44.2091 48 42 48H22C19.7909 48 18 46.2091 18 44V20Z" stroke="#0078D4" strokeWidth="3.5"/>
        <circle cx="28" cy="28" r="4.5" fill="#00BCF2"/>
        <circle cx="36" cy="36" r="4.5" fill="#0078D4"/>
        <path d="M28 28L36 36" stroke="#00BCF2" strokeWidth="2.5" strokeDasharray="2 2"/>
        <path d="M14 32H18M46 32H50" stroke="#0078D4" strokeWidth="3.5" strokeLinecap="round"/>
      </svg>
    );
  }

  // 13. ADLS Gen2 / Azure Storage
  if (normalized.includes('adls') || normalized.includes('datalake') || normalized.includes('storage') || normalized.includes('bronze')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <rect width="64" height="64" rx="12" fill="#0089D6" fillOpacity="0.18" />
        <path d="M32 14L48 22V42L32 50L16 42V22L32 14Z" fill="#0078D4" stroke="#00BCF2" strokeWidth="2.5"/>
        <path d="M32 14V50M16 22L48 42M48 22L16 42" stroke="#ffffff" strokeWidth="2" strokeOpacity="0.6"/>
      </svg>
    );
  }

  // 14. Delta Lake
  if (normalized.includes('deltalake') || normalized.includes('delta')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <path d="M32 10L54 48H10L32 10Z" fill="#00A9E0" fillOpacity="0.25" stroke="#00A9E0" strokeWidth="3"/>
        <path d="M32 24L44 46H20L32 24Z" fill="#005A9C"/>
        <circle cx="32" cy="18" r="3.5" fill="#00E5FF"/>
      </svg>
    );
  }

  // 15. Synapse Analytics
  if (normalized.includes('synapse') || normalized.includes('bi') || normalized.includes('analytics')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <rect width="64" height="64" rx="12" fill="#0078D4" fillOpacity="0.18" />
        <circle cx="32" cy="32" r="14" stroke="#0078D4" strokeWidth="3" />
        <circle cx="32" cy="20" r="4" fill="#00BCF2" />
        <circle cx="42" cy="38" r="4" fill="#5C2D91" />
        <circle cx="22" cy="38" r="4" fill="#0078D4" />
        <line x1="32" y1="20" x2="42" y2="38" stroke="#00BCF2" strokeWidth="2"/>
        <line x1="42" y1="38" x2="22" y2="38" stroke="#00BCF2" strokeWidth="2"/>
        <line x1="22" y1="38" x2="32" y2="20" stroke="#00BCF2" strokeWidth="2"/>
      </svg>
    );
  }

  // 16. Azure SQL DB
  if (normalized.includes('azuresql') || normalized.includes('sqldb')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <rect width="64" height="64" rx="12" fill="#0078D4" fillOpacity="0.18" />
        <ellipse cx="32" cy="20" rx="16" ry="6" fill="#0078D4" stroke="#00BCF2" strokeWidth="2.5"/>
        <path d="M16 20V32C16 35.3137 23.1634 38 32 38C40.8366 38 48 35.3137 48 32V20" stroke="#00BCF2" strokeWidth="2.5"/>
        <path d="M16 32V44C16 47.3137 23.1634 50 32 50C40.8366 50 48 47.3137 48 44V32" stroke="#00BCF2" strokeWidth="2.5"/>
      </svg>
    );
  }

  // 17. Azure Event Hub
  if (normalized.includes('eventhub') || normalized.includes('event') || normalized.includes('streaming')) {
    return (
      <svg className={className} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: size, height: size }}>
        <rect width="64" height="64" rx="12" fill="#804998" fillOpacity="0.2" />
        <circle cx="32" cy="32" r="18" stroke="#804998" strokeWidth="2.5" strokeDasharray="4 2"/>
        <circle cx="32" cy="32" r="6" fill="#B146C2"/>
        <circle cx="20" cy="24" r="3.5" fill="#804998"/>
        <circle cx="44" cy="24" r="3.5" fill="#804998"/>
        <circle cx="32" cy="48" r="3.5" fill="#804998"/>
      </svg>
    );
  }

  // 18. Generic Azure
  if (normalized.includes('azure') || normalized.includes('cloud')) {
    return (
      <svg className={className} viewBox="0 0 24 24" fill="currentColor" style={{ width: size, height: size }}>
        <path fill="#0089D6" d="M13.02 0l-7.4 13.9 6.2 3.6 8.18-17.5zM3.4 15.3l-3.4 6.7 9.8 2 3.4-6.8z"/>
      </svg>
    );
  }

  // 19. Data Source / CSV / JSON
  if (normalized.includes('csv') || normalized.includes('json') || normalized.includes('source') || normalized.includes('producer')) {
    return <FileJson className={`${className} text-emerald-400`} size={size} />;
  }

  // 20. ETL / ELT / Governance / Batch
  if (normalized.includes('etl') || normalized.includes('elt') || normalized.includes('pipeline')) {
    return <Workflow className={`${className} text-cyan-400`} size={size} />;
  }
  if (normalized.includes('governance') || normalized.includes('quality')) {
    return <Layers className={`${className} text-amber-400`} size={size} />;
  }

  // Fallback
  return <Database className={`${className} text-cyan-400`} size={size} />;
};

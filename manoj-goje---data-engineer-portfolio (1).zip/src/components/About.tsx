import React from 'react';
import {
  ShieldCheck,
  Layers,
  CheckCircle2,
  Search,
  Compass,
  Server,
  Activity,
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { useTheme } from '../context/ThemeContext';

export const About: React.FC = () => {
  const { darkMode } = useTheme();

  const pillars = [
    {
      icon: Compass,
      title: 'Geospatial & Mapping Pipelines',
      desc: 'Hands-on expertise processing large-scale spatial coordinates, spatial layers, GIS geometries, and complex structured/semi-structured datasets.',
      color: darkMode
        ? 'text-cyan-300 bg-[#001833] border-[#1b3c73]'
        : 'text-[#0078D4] bg-[#eff6ff] border-[#bfdbfe]',
    },
    {
      icon: Layers,
      title: 'Azure Cloud & Lakehouse',
      desc: 'Orchestrating Azure Data Factory, Databricks Spark compute, ADLS Gen2 storage, and Delta Lake Medallion architectures for ML-ready feature stores.',
      color: darkMode
        ? 'text-sky-300 bg-[#001833] border-[#1b3c73]'
        : 'text-[#0078D4] bg-[#eff6ff] border-[#bfdbfe]',
    },
    {
      icon: Search,
      title: 'Incident Diagnosis & RCA',
      desc: 'Deep troubleshooting of schema drifts, pipeline failures, data anomalies, checkpoint corruptions, and multi-database discrepancies.',
      color: darkMode
        ? 'text-amber-300 bg-[#001833] border-[#1b3c73]'
        : 'text-amber-600 bg-amber-50 border-amber-200',
    },
    {
      icon: ShieldCheck,
      title: 'SLA-Driven Data Quality',
      desc: 'Enforcing 99%+ accuracy standards, automated validation rules, schema evolution locks, and reducing turnaround times by 40%.',
      color: darkMode
        ? 'text-emerald-300 bg-[#001833] border-[#1b3c73]'
        : 'text-emerald-600 bg-emerald-50 border-emerald-200',
    },
  ];

  return (
    <section id="about" className={`py-16 border-y relative transition-colors ${
      darkMode ? 'bg-[#081528] border-[#1b3c73]' : 'bg-[#f4f8fc] border-[#d2e3fc]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono mb-2 ${
            darkMode
              ? 'border-[#0078D4]/40 bg-[#0078D4]/10 text-cyan-300'
              : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
          }`}>
            <span>DATA.OPERATIONS / EXECUTIVE SUMMARY</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            About &amp; Executive Summary
          </h2>
          <div className="w-16 h-1 bg-[#0078D4] mx-auto mt-3 rounded-full" />
        </div>

        {/* Main Bio Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className={`lg:col-span-8 rounded-xl border p-6 sm:p-7 shadow-lg transition-colors ${
            darkMode
              ? 'bg-[#0d1b32] border-[#1b3c73]'
              : 'bg-white border-[#d2e3fc] text-slate-800'
          }`}>
            
            <div className={`flex items-center justify-between pb-3 mb-4 border-b text-xs font-mono ${
              darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
            }`}>
              <span className={`flex items-center gap-1.5 ${
                darkMode ? 'text-slate-400' : 'text-slate-500'
              }`}>
                <Server className="w-3.5 h-3.5 text-[#0078D4]" />
                <span>Executive Bio &bull; Cognizant Technology Solutions</span>
              </span>
              <span className="text-emerald-500 font-semibold flex items-center gap-1">
                <Activity className="w-3 h-3 animate-pulse" />
                Active Engineer
              </span>
            </div>

            <p className={`text-base sm:text-lg leading-relaxed ${
              darkMode ? 'text-slate-200' : 'text-slate-700'
            }`}>
              {PERSONAL_INFO.summary}
            </p>

            {/* Bullet Highlights */}
            <div className={`grid grid-cols-1 sm:grid-cols-2 gap-3 mt-6 pt-5 border-t text-xs sm:text-sm font-sans ${
              darkMode ? 'border-[#1b3c73] text-slate-300' : 'border-slate-200 text-slate-700'
            }`}>
              <div className="flex items-start gap-2">
                <CheckCircle2 className={`w-4 h-4 flex-shrink-0 mt-0.5 ${darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}`} />
                <span>Geospatial, clinical, and high-volume multi-format pipeline processing</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className={`w-4 h-4 flex-shrink-0 mt-0.5 ${darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}`} />
                <span>End-to-end Medallion (Bronze/Silver/Gold) Lakehouse architecture</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className={`w-4 h-4 flex-shrink-0 mt-0.5 ${darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}`} />
                <span>Distributed data transformations via PySpark on Databricks clusters</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className={`w-4 h-4 flex-shrink-0 mt-0.5 ${darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}`} />
                <span>Rigorous SLA monitoring &amp; automated incident triage workflows</span>
              </div>
            </div>
          </div>

          {/* Quick Metrics Column */}
          <div className="lg:col-span-4 grid grid-cols-2 lg:grid-cols-1 gap-3.5">
            {PERSONAL_INFO.stats.map((stat, idx) => (
              <div
                key={idx}
                className={`border p-4 rounded-xl transition-all shadow-sm ${
                  darkMode
                    ? 'bg-[#0d1b32] border-[#1b3c73] hover:border-[#0078D4]'
                    : 'bg-white border-[#d2e3fc] hover:border-[#0078D4]'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-2xl sm:text-3xl font-extrabold font-mono ${
                    darkMode ? 'text-cyan-300' : 'text-[#0078D4]'
                  }`}>
                    {stat.value}
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    darkMode
                      ? 'text-cyan-300 bg-[#001024] border-[#1b3c73]'
                      : 'text-[#0078D4] bg-[#eff6ff] border-[#bfdbfe]'
                  }`}>
                    {stat.highlight}
                  </span>
                </div>
                <div className={`text-xs font-medium ${
                  darkMode ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
          {pillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <div
                key={idx}
                className={`p-5 rounded-xl border transition-all hover:-translate-y-1 shadow-md ${
                  darkMode
                    ? 'bg-[#0d1b32] border-[#1b3c73] hover:bg-[#0f2244]'
                    : 'bg-white border-[#d2e3fc] hover:shadow-lg'
                }`}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 border ${pillar.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className={`text-base font-bold mb-2 ${
                  darkMode ? 'text-white' : 'text-slate-900'
                }`}>
                  {pillar.title}
                </h3>
                <p className={`text-xs leading-relaxed ${
                  darkMode ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  {pillar.desc}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

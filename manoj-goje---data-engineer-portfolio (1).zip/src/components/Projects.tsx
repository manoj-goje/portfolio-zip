import React from 'react';
import { PROJECTS_LIST } from '../data/portfolioData';
import { TechIcon } from './TechIcon';
import { PipelineFlowDiagram } from './PipelineFlowDiagram';
import {
  FolderGit2,
  CheckCircle2,
  Workflow,
  Activity,
  Play,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const Projects: React.FC<{ darkMode?: boolean }> = () => {
  const { darkMode } = useTheme();

  return (
    <section id="projects" className={`py-16 relative transition-colors ${
      darkMode ? 'bg-[#080f1e]' : 'bg-[#f4f8fc]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono mb-2 ${
            darkMode
              ? 'border-[#0078D4]/40 bg-[#0078D4]/10 text-cyan-300'
              : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
          }`}>
            <span>DATA.PIPELINES / WORKSPACES &amp; ARCHITECTURE</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Key Data Engineering Projects
          </h2>
          <p className={`text-sm sm:text-base mt-2 ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Scalable Azure pipelines with end-to-end flow diagrams, schema governance, and Medallion Lakehouse design.
          </p>
          <div className="w-16 h-1 bg-[#0078D4] mx-auto mt-3 rounded-full" />
        </div>

        {/* 2-Column Responsive Card Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
          {PROJECTS_LIST.map((project, idx) => {
            return (
              <div
                key={project.id}
                className={`flex flex-col justify-between rounded-xl border p-5 sm:p-6 shadow-xl transition-all duration-300 relative group ${
                  darkMode
                    ? 'border-[#1b3c73] bg-[#0d1b32] hover:border-[#0078D4]'
                    : 'border-[#d2e3fc] bg-white hover:border-[#0078D4] hover:shadow-2xl'
                }`}
              >
                {/* Top Section */}
                <div className="space-y-4">
                  
                  {/* Badge & Status */}
                  <div className="flex items-center justify-between">
                    <span className={`text-[11px] font-mono font-bold px-2.5 py-1 rounded border ${
                      darkMode
                        ? 'text-cyan-300 bg-[#001024] border-[#1b3c73]'
                        : 'text-[#0078D4] bg-[#eff6ff] border-[#bfdbfe]'
                    }`}>
                      PIPELINE 0{idx + 1}
                    </span>
                    <span className="text-xs text-emerald-500 font-mono flex items-center gap-1.5 bg-emerald-950/20 px-2 py-0.5 rounded border border-emerald-500/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Succeeded &bull; Production</span>
                    </span>
                  </div>

                  {/* Title & Subtitle */}
                  <div>
                    <h3 className={`text-xl sm:text-2xl font-bold transition-colors ${
                      darkMode
                        ? 'text-white group-hover:text-cyan-300'
                        : 'text-slate-900 group-hover:text-[#0078D4]'
                    }`}>
                      {project.title}
                    </h3>
                    <p className={`text-xs sm:text-sm font-semibold font-mono mt-1 ${
                      darkMode ? 'text-cyan-300' : 'text-[#0078D4]'
                    }`}>
                      {project.subtitle}
                    </p>
                  </div>

                  {/* Tagline */}
                  <p className={`text-xs leading-relaxed font-sans ${
                    darkMode ? 'text-slate-300' : 'text-slate-600'
                  }`}>
                    {project.tagline}
                  </p>

                  {/* Tech Stack Logo Row */}
                  <div className="pt-1">
                    <span className={`text-[11px] font-mono block mb-2 ${
                      darkMode ? 'text-slate-400' : 'text-slate-500'
                    }`}>
                      LINKED SERVICES &amp; COMPUTE:
                    </span>
                    <div className="flex flex-wrap items-center gap-2">
                      {project.techStack.map((tech, tIdx) => (
                        <div
                          key={tIdx}
                          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs shadow-sm ${
                            darkMode
                              ? 'bg-[#001024] border-[#1b3c73] text-slate-200'
                              : 'bg-[#f8fafc] border-slate-200 text-slate-700'
                          }`}
                        >
                          <TechIcon name={tech.iconKey || tech.name} className="w-3.5 h-3.5" />
                          <span className="text-[11px] font-medium">{tech.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Horizontal Data-Flow Diagram */}
                  <div className="pt-2">
                    <PipelineFlowDiagram
                      nodes={project.flowNodes}
                      edges={project.flowEdges}
                      isDark={darkMode}
                    />
                  </div>

                  {/* Description Bullets */}
                  <div className={`space-y-2 pt-2 text-xs font-sans ${
                    darkMode ? 'text-slate-300' : 'text-slate-700'
                  }`}>
                    {project.bullets.map((b, bIdx) => (
                      <div key={bIdx} className="flex items-start gap-2">
                        <CheckCircle2 className={`w-3.5 h-3.5 flex-shrink-0 mt-0.5 ${
                          darkMode ? 'text-cyan-400' : 'text-[#0078D4]'
                        }`} />
                        <span className="leading-relaxed">{b}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom Impact Metric */}
                <div className={`mt-5 pt-3 border-t flex items-center justify-between text-xs ${
                  darkMode ? 'border-[#1b3c73] text-slate-300' : 'border-slate-200 text-slate-600'
                }`}>
                  <span className={`font-mono text-[11px] ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    STATUS: <strong className={darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}>ACID PARITY VERIFIED</strong>
                  </span>
                  <span className="text-[11px] font-mono text-emerald-500 font-semibold">
                    100% Run Health
                  </span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

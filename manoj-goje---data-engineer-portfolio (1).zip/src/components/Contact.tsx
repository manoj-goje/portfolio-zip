import React, { useState } from 'react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { TechIcon } from './TechIcon';
import {
  Mail,
  Phone,
  Send,
  CheckCircle2,
  Copy,
  ArrowUpRight,
  ExternalLink,
  Briefcase,
  AlertCircle,
  MessageCircle,
  Server,
  Activity,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useTheme } from '../context/ThemeContext';

export const Contact: React.FC = () => {
  const { darkMode } = useTheme();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Opportunity for Job / Hiring Inquiry',
    message: '',
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const subjectOptions = [
    'Opportunity for Job / Hiring Inquiry',
    'Full-Time Data Operations / Engineer Position',
    'Azure Lakehouse & Medallion Pipeline Project',
    'GIS & Mapping Data Operations Role',
    'Contract / Freelance / Technical Consultation',
    'General Professional Discussion',
  ];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2500);
  };

  // Generate formatted subject & body
  const emailSubject = `[Job Opportunity / Portfolio] ${formData.subject} - from ${formData.name || 'Visitor'}`;
  const emailBody = `Hi Manoj,\n\nI am contacting you regarding: ${formData.subject}\n\nSender Name: ${formData.name}\nSender Email: ${formData.email}\n\nMessage:\n${formData.message}\n\n---\nSent via Portfolio Contact Form (https://www.linkedin.com/in/manoj-g-)`;

  const mailtoUrl = `mailto:${PERSONAL_INFO.email}?subject=${encodeURIComponent(
    emailSubject
  )}&body=${encodeURIComponent(emailBody)}`;

  // Web mail direct compose URLs for 100% delivery guarantee
  const gmailComposeUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(
    PERSONAL_INFO.email
  )}&su=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;

  const outlookComposeUrl = `https://outlook.live.com/owa/?path=/mail/action/compose&to=${encodeURIComponent(
    PERSONAL_INFO.email
  )}&subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;

  const whatsappUrl = `https://wa.me/918805861929?text=${encodeURIComponent(
    `Hi Manoj, I saw your Data Operations & Azure Lakehouse portfolio. I would like to discuss: ${formData.subject}`
  )}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#0078D4', '#29b6f6', '#10b981', '#ffffff'],
      });
    } catch {
      // safe fallback
    }

    setIsSubmitted(true);

    // Attempt direct launch via temporary link
    try {
      const link = document.createElement('a');
      link.href = mailtoUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      window.location.href = mailtoUrl;
    }
  };

  const copyFullMessage = () => {
    const fullText = `To: ${PERSONAL_INFO.email}\nSubject: ${emailSubject}\n\n${emailBody}`;
    handleCopy(fullText, 'fullMessage');
  };

  return (
    <section id="contact" className={`py-16 border-t relative transition-colors ${
      darkMode ? 'bg-[#081528] border-[#1b3c73]' : 'bg-[#ffffff] border-[#d2e3fc]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono mb-2 ${
            darkMode
              ? 'border-[#0078D4]/40 bg-[#0078D4]/10 text-cyan-300'
              : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
          }`}>
            <span>COMMUNICATIONS / DIRECT DISPATCH</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Let's Connect &amp; Discuss Opportunities
          </h2>
          <p className={`text-sm sm:text-base mt-2 ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Actively open to Data Engineering, Azure Lakehouse, and GIS Data Operations roles. Send a direct message below.
          </p>
          <div className="w-16 h-1 bg-[#0078D4] mx-auto mt-3 rounded-full" />
        </div>

        {/* Contact Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-5xl mx-auto">
          
          {/* Left Column: Direct Reach Cards */}
          <div className="lg:col-span-5 space-y-3.5">
            
            {/* Direct Email Card */}
            <div className={`rounded-xl border p-4.5 transition-all shadow-md ${
              darkMode
                ? 'bg-[#0d1b32] border-[#1b3c73] hover:border-[#0078D4]'
                : 'bg-white border-[#d2e3fc] hover:border-[#0078D4]'
            }`}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg border flex items-center justify-center ${
                    darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#eff6ff] border-[#bfdbfe]'
                  }`}>
                    <Mail className={`w-5 h-5 ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`} />
                  </div>
                  <div>
                    <span className={`text-[11px] font-mono block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>PRIMARY INBOX</span>
                    <a
                      href={`mailto:${PERSONAL_INFO.email}`}
                      className={`text-sm font-semibold transition-colors break-all font-mono ${
                        darkMode ? 'text-white hover:text-cyan-300' : 'text-slate-900 hover:text-[#0078D4]'
                      }`}
                    >
                      {PERSONAL_INFO.email}
                    </a>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(PERSONAL_INFO.email, 'email')}
                  className={`p-1.5 rounded border transition-colors cursor-pointer ${
                    darkMode
                      ? 'bg-[#001024] text-slate-400 hover:text-white border-[#1b3c73]'
                      : 'bg-[#f8fafc] text-slate-500 hover:text-slate-900 border-slate-200'
                  }`}
                  title="Copy email"
                >
                  {copiedField === 'email' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Direct Phone / WhatsApp Card */}
            <div className={`rounded-xl border p-4.5 transition-all shadow-md ${
              darkMode
                ? 'bg-[#0d1b32] border-[#1b3c73] hover:border-emerald-600'
                : 'bg-white border-[#d2e3fc] hover:border-emerald-500'
            }`}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg border flex items-center justify-center ${
                    darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#ecfdf5] border-emerald-200'
                  }`}>
                    <Phone className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <span className={`text-[11px] font-mono block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>PHONE &amp; WHATSAPP</span>
                    <a
                      href={`tel:${PERSONAL_INFO.phone}`}
                      className={`text-sm font-semibold transition-colors font-mono ${
                        darkMode ? 'text-white hover:text-cyan-300' : 'text-slate-900 hover:text-[#0078D4]'
                      }`}
                    >
                      {PERSONAL_INFO.phoneFormatted}
                    </a>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 rounded bg-emerald-950/20 text-emerald-600 hover:bg-emerald-950/30 border border-emerald-500/30 transition-colors"
                    title="Chat on WhatsApp"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </a>
                  <button
                    type="button"
                    onClick={() => handleCopy(PERSONAL_INFO.phone, 'phone')}
                    className={`p-1.5 rounded border transition-colors cursor-pointer ${
                      darkMode
                        ? 'bg-[#001024] text-slate-400 hover:text-white border-[#1b3c73]'
                        : 'bg-[#f8fafc] text-slate-500 hover:text-slate-900 border-slate-200'
                    }`}
                    title="Copy phone"
                  >
                    {copiedField === 'phone' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* LinkedIn Profile Card */}
            <div className={`rounded-xl border p-4.5 transition-all shadow-md ${
              darkMode
                ? 'bg-[#0d1b32] border-[#1b3c73] hover:border-[#0078D4]'
                : 'bg-white border-[#d2e3fc] hover:border-[#0078D4]'
            }`}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg border flex items-center justify-center ${
                    darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#eff6ff] border-[#bfdbfe]'
                  }`}>
                    <TechIcon name="linkedin" className="w-5 h-5" />
                  </div>
                  <div>
                    <span className={`text-[11px] font-mono block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>LINKEDIN PROFILE</span>
                    <a
                      href={PERSONAL_INFO.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`text-sm font-semibold transition-colors flex items-center gap-1 font-mono ${
                        darkMode ? 'text-white hover:text-cyan-300' : 'text-slate-900 hover:text-[#0078D4]'
                      }`}
                    >
                      <span>{PERSONAL_INFO.linkedinHandle}</span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-[#0078D4]" />
                    </a>
                  </div>
                </div>
                <a
                  href={PERSONAL_INFO.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`p-1.5 rounded border transition-colors ${
                    darkMode
                      ? 'bg-[#001024] text-slate-400 hover:text-white border-[#1b3c73]'
                      : 'bg-[#f8fafc] text-slate-500 hover:text-slate-900 border-slate-200'
                  }`}
                  title="Open LinkedIn"
                >
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Job Opportunity Status Banner */}
            <div className={`rounded-xl border p-4 text-xs space-y-2 ${
              darkMode
                ? 'bg-[#001833] border-[#0078D4]/40 text-slate-300'
                : 'bg-[#eff6ff] border-[#bfdbfe] text-slate-700'
            }`}>
              <div className={`flex items-center gap-2 font-semibold font-mono ${
                darkMode ? 'text-cyan-300' : 'text-[#0078D4]'
              }`}>
                <Briefcase className="w-4 h-4" />
                <span>AVAILABILITY: OPEN FOR IMMEDIATE HIRING</span>
              </div>
              <p className="leading-relaxed text-[11px]">
                Seeking high-impact full-time roles in Azure Data Engineering, Databricks Lakehouse pipelines, PySpark transformation systems, and SLA monitoring.
              </p>
            </div>

          </div>

          {/* Right Column: Direct Message Dispatch Blade Form */}
          <div className="lg:col-span-7">
            <div className={`rounded-xl border p-6 shadow-xl relative transition-colors ${
              darkMode
                ? 'bg-[#0d1b32] border-[#1b3c73]'
                : 'bg-white border-[#d2e3fc]'
            }`}>
              
              <div className={`flex items-center justify-between pb-3 mb-5 border-b ${
                darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
              }`}>
                <h3 className={`text-base font-bold flex items-center gap-2 ${
                  darkMode ? 'text-white' : 'text-slate-900'
                }`}>
                  <Send className="w-4 h-4 text-[#0078D4]" />
                  <span>Send Direct Message</span>
                </h3>
                <span className="text-[10px] font-mono text-emerald-500 bg-emerald-950/20 px-2 py-0.5 rounded border border-emerald-500/30">
                  Direct Dispatch
                </span>
              </div>

              {isSubmitted && (
                <div className={`mb-5 p-4 rounded-lg border text-xs space-y-2 ${
                  darkMode
                    ? 'bg-[#001833] border-[#0078D4]/50 text-slate-300'
                    : 'bg-[#eff6ff] border-[#bfdbfe] text-slate-700'
                }`}>
                  <div className="flex items-center gap-2 text-emerald-500 font-semibold font-mono">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Message Ready for Transmission!</span>
                  </div>
                  <p>
                    Click an instant webmail provider below to guarantee 100% direct arrival in Manoj's primary inbox:
                  </p>
                  
                  {/* 1-Click Direct Webmail Launch Buttons */}
                  <div className="flex flex-wrap items-center gap-2 pt-2">
                    <a
                      href={gmailComposeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#c5221f] hover:bg-[#a51d1a] text-white text-xs font-semibold shadow-sm transition-all"
                    >
                      <span>Open in Gmail</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    <a
                      href={outlookComposeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#0078D4] hover:bg-[#106ebe] text-white text-xs font-semibold shadow-sm transition-all"
                    >
                      <span>Open in Outlook</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    <a
                      href={mailtoUrl}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold border transition-all ${
                        darkMode
                          ? 'bg-[#001024] hover:bg-[#163566] text-cyan-300 border-[#1b3c73]'
                          : 'bg-white hover:bg-slate-50 text-[#0078D4] border-[#bfdbfe]'
                      }`}
                    >
                      <span>Default Mail App</span>
                    </a>

                    <button
                      type="button"
                      onClick={copyFullMessage}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold border transition-all cursor-pointer ${
                        darkMode
                          ? 'bg-[#001024] hover:bg-[#163566] text-slate-200 border-[#1b3c73]'
                          : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300'
                      }`}
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedField === 'fullMessage' ? 'Copied Full Message!' : 'Copy Full Message'}</span>
                    </button>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                
                {/* Name & Email in 2 columns */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-xs font-mono mb-1.5 ${
                      darkMode ? 'text-slate-300' : 'text-slate-700'
                    }`}>
                      Your Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="e.g. Satya Nadella"
                      className={`w-full px-3 py-2 rounded-md border text-xs font-sans outline-none transition-colors ${
                        darkMode
                          ? 'bg-[#001024] border-[#1b3c73] focus:border-[#0078D4] text-white placeholder-slate-500'
                          : 'bg-white border-slate-300 focus:border-[#0078D4] text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>

                  <div>
                    <label className={`block text-xs font-mono mb-1.5 ${
                      darkMode ? 'text-slate-300' : 'text-slate-700'
                    }`}>
                      Your Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="e.g. recruiter@enterprise.com"
                      className={`w-full px-3 py-2 rounded-md border text-xs font-sans outline-none transition-colors ${
                        darkMode
                          ? 'bg-[#001024] border-[#1b3c73] focus:border-[#0078D4] text-white placeholder-slate-500'
                          : 'bg-white border-slate-300 focus:border-[#0078D4] text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>
                </div>

                {/* Subject Dropdown */}
                <div>
                  <label className={`block text-xs font-mono mb-1.5 flex items-center justify-between ${
                    darkMode ? 'text-slate-300' : 'text-slate-700'
                  }`}>
                    <span>Subject / Inquiring Reason *</span>
                    <span className={`text-[10px] font-mono ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`}>Dropdown Selector</span>
                  </label>
                  <select
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 rounded-md border text-xs font-sans outline-none transition-colors cursor-pointer ${
                      darkMode
                        ? 'bg-[#001024] border-[#1b3c73] focus:border-[#0078D4] text-white'
                        : 'bg-white border-slate-300 focus:border-[#0078D4] text-slate-900'
                    }`}
                  >
                    {subjectOptions.map((opt, oIdx) => (
                      <option key={oIdx} value={opt} className={darkMode ? 'bg-[#001024] text-white' : 'bg-white text-slate-900'}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Message Box */}
                <div>
                  <label className={`block text-xs font-mono mb-1.5 ${
                    darkMode ? 'text-slate-300' : 'text-slate-700'
                  }`}>
                    Your Message / Role Details *
                  </label>
                  <textarea
                    name="message"
                    rows={4}
                    required
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Provide role description, company, team scope, salary range, or interview schedule..."
                    className={`w-full px-3 py-2 rounded-md border text-xs font-sans outline-none transition-colors resize-none ${
                      darkMode
                        ? 'bg-[#001024] border-[#1b3c73] focus:border-[#0078D4] text-white placeholder-slate-500'
                        : 'bg-white border-slate-300 focus:border-[#0078D4] text-slate-900 placeholder-slate-400'
                    }`}
                  />
                </div>

                {/* Submit Action */}
                <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-[#0078D4] hover:bg-[#106ebe] text-white font-semibold text-xs tracking-wide shadow-md transition-all hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Transmit Message Directly</span>
                  </button>

                  <span className={`text-[10px] font-mono ${
                    darkMode ? 'text-slate-400' : 'text-slate-500'
                  }`}>
                    Direct delivery to manojgoje02@gmail.com
                  </span>
                </div>

              </form>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

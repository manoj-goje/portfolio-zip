import React from 'react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { TechIcon } from './TechIcon';
import { ArrowUp, Mail, Phone, Server, ShieldCheck, Activity } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const Footer: React.FC = () => {
  const { darkMode } = useTheme();

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <footer className={`border-t text-xs py-10 relative transition-colors ${
      darkMode ? 'bg-[#001024] border-[#1b3c73] text-slate-400' : 'bg-white border-[#d2e3fc] text-slate-600'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className={`flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b ${
          darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
        }`}>
          
          {/* Brand Info */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-[#0078D4] flex items-center justify-center text-white font-bold font-mono text-xs shadow-sm">
                MG
              </div>
              <span className={`font-bold text-sm ${darkMode ? 'text-white' : 'text-slate-900'}`}>{PERSONAL_INFO.name}</span>
            </div>
            <p className={`font-mono text-[11px] ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
              {PERSONAL_INFO.title} &bull; {PERSONAL_INFO.location}
            </p>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-2.5">
            <a
              href={PERSONAL_INFO.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className={`p-2 rounded border transition-colors ${
                darkMode
                  ? 'bg-[#0d1b32] hover:bg-[#163566] text-slate-300 hover:text-cyan-300 border-[#1b3c73]'
                  : 'bg-[#f8fafc] hover:bg-slate-100 text-slate-700 hover:text-[#0078D4] border-slate-200'
              }`}
              title="LinkedIn Profile"
            >
              <TechIcon name="linkedin" className="w-4 h-4" />
            </a>

            <a
              href={`mailto:${PERSONAL_INFO.email}`}
              className={`p-2 rounded border transition-colors ${
                darkMode
                  ? 'bg-[#0d1b32] hover:bg-[#163566] text-slate-300 hover:text-cyan-300 border-[#1b3c73]'
                  : 'bg-[#f8fafc] hover:bg-slate-100 text-slate-700 hover:text-[#0078D4] border-slate-200'
              }`}
              title="Send Email"
            >
              <Mail className="w-4 h-4" />
            </a>

            <a
              href={`tel:${PERSONAL_INFO.phone}`}
              className={`p-2 rounded border transition-colors ${
                darkMode
                  ? 'bg-[#0d1b32] hover:bg-[#163566] text-slate-300 hover:text-cyan-300 border-[#1b3c73]'
                  : 'bg-[#f8fafc] hover:bg-slate-100 text-slate-700 hover:text-[#0078D4] border-slate-200'
              }`}
              title="Call / WhatsApp"
            >
              <Phone className="w-4 h-4" />
            </a>
          </div>

          {/* Back to Top */}
          <button
            type="button"
            onClick={scrollToTop}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded border transition-colors cursor-pointer text-xs font-mono ${
              darkMode
                ? 'bg-[#0d1b32] hover:bg-[#163566] text-slate-300 hover:text-white border-[#1b3c73]'
                : 'bg-[#f8fafc] hover:bg-slate-100 text-slate-700 hover:text-slate-900 border-slate-200'
            }`}
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Bottom copyright & Azure platform metadata */}
        <div className={`flex flex-col sm:flex-row items-center justify-between gap-3 pt-5 text-[11px] ${
          darkMode ? 'text-slate-400' : 'text-slate-500'
        }`}>
          <div>
            &copy; {new Date().getFullYear()} {PERSONAL_INFO.name}. Data Operations Portal &bull; Resource ID: <span className={`font-mono ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>/subscriptions/sub-dataops-001</span>
          </div>

          <div className="flex items-center gap-2 font-mono text-emerald-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Azure Medallion Lakehouse &bull; SLA 99.9% Online</span>
          </div>
        </div>

      </div>
    </footer>
  );
};

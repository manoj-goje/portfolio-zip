import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Terminal,
  Bell,
  HelpCircle,
  Menu,
  X,
  FileDown,
  Database,
  Briefcase,
  FolderGit2,
  Award,
  GraduationCap,
  Mail,
  Trophy,
  Activity,
  Play,
  RotateCw,
  Plus,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  Sparkles,
  Sun,
  Moon,
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { useTheme } from '../context/ThemeContext';
import { downloadResumePDF } from '../utils/generateResumePDF';

interface NavbarProps {
  onOpenResume: () => void;
  onRunPipeline?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenResume,
  onRunPipeline,
}) => {
  const { darkMode, toggleDarkMode } = useTheme();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [cloudShellOpen, setCloudShellOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');
  const [terminalCommand, setTerminalCommand] = useState('');
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    'Welcome to Azure Cloud Shell (Bash)',
    'Connected to Manoj Goje Data Operations Subscription: sub-dataops-prod-001',
    'Type "help", "az cert list", "az pipeline run", "az skills", "az resume", or "cls"',
  ]);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);

  const navLinks = [
    { name: 'Dashboard Overview', href: '#hero', icon: Activity, tag: 'Overview' },
    { name: 'Resource Skills', href: '#skills', icon: Database, tag: 'Services' },
    { name: 'Activity Log & SLA Ops', href: '#experience', icon: Briefcase, tag: 'History' },
    { name: 'Data Pipelines & Projects', href: '#projects', icon: FolderGit2, tag: 'Pipelines' },
    { name: 'Leadership & Contests', href: '#leadership', icon: Trophy, tag: 'Governance' },
    { name: 'Advisor & Certifications', href: '#certifications', icon: Award, tag: 'Security' },
    { name: 'Resource Providers / Education', href: '#education', icon: GraduationCap, tag: 'Providers' },
    { name: 'Help + Support / Contact', href: '#contact', icon: Mail, tag: 'Support' },
  ];

  const searchableItems = [
    { title: 'DP-203: Azure Data Engineer Associate', category: 'Certifications', section: '#certifications' },
    { title: 'Databricks Certified Data Engineer', category: 'Certifications', section: '#certifications' },
    { title: 'AZ-104: Azure Administrator Associate', category: 'Certifications', section: '#certifications' },
    { title: 'Azure Data Factory (ADF v2)', category: 'Skills', section: '#skills' },
    { title: 'Azure Databricks & PySpark', category: 'Skills', section: '#skills' },
    { title: 'ADLS Gen2 & Delta Lakehouse', category: 'Skills', section: '#skills' },
    { title: 'Cognizant Technology Solutions', category: 'Experience', section: '#experience' },
    { title: 'Medallion Lakehouse Pipeline', category: 'Projects', section: '#projects' },
    { title: 'GIS Data Pipeline Ingestion', category: 'Projects', section: '#projects' },
    { title: 'Tournament Captain (12-Player)', category: 'Leadership', section: '#leadership' },
    { title: 'Download Manoj Resume (Exact PDF)', category: 'Actions', action: () => downloadResumePDF() },
    { title: 'Contact / Hire Manoj Goje', category: 'Support', section: '#contact' },
  ];

  const filteredSearch = searchableItems.filter((item) =>
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Close notifications on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        notificationsRef.current &&
        !notificationsRef.current.contains(event.target as Node)
      ) {
        setNotificationsOpen(false);
      }
    };
    if (notificationsOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [notificationsOpen]);

  // Global keyboard shortcut for search (Alt+S or Ctrl+/)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey && e.key === '/') || (e.altKey && e.key.toLowerCase() === 's')) {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Section scroll spy
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'about', 'skills', 'experience', 'projects', 'leadership', 'certifications', 'education', 'contact'];
      const scrollPosition = window.scrollY + 180;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      const offset = 90;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
    setSidebarOpen(false);
    setSearchOpen(false);
  };

  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = terminalCommand.trim().toLowerCase();
    let response = '';

    if (cmd === 'help') {
      response = 'Available commands: az cert list, az pipeline run, az skills, az contact, az resume, clear';
    } else if (cmd === 'az cert list') {
      response = '[✓] DP-203 Azure Data Engineer\n[✓] Databricks Data Engineer\n[✓] AZ-104 Azure Administrator\n[✓] Oracle 1Z0-1132-24 Agentic AI';
    } else if (cmd === 'az pipeline run') {
      response = 'Initiating Medallion Lakehouse ingestion run: Bronze -> Silver -> Gold (Delta Lake ACID verified)';
      scrollToSection('#projects');
    } else if (cmd === 'az skills') {
      response = 'Skills: Azure Data Factory, Azure Databricks, PySpark, ADLS Gen2, Synapse, SQL, Python, Git';
    } else if (cmd === 'az resume') {
      response = 'Downloading Manoj Goje verified curriculum vitae (PDF)...';
      downloadResumePDF();
    } else if (cmd === 'az contact') {
      response = 'Navigating to Support & Hiring Portal (manojgoje02@gmail.com)...';
      scrollToSection('#contact');
    } else if (cmd === 'clear' || cmd === 'cls') {
      setTerminalLogs(['Azure Cloud Shell ready. Type "help" for options.']);
      setTerminalCommand('');
      return;
    } else if (cmd) {
      response = `Command not recognized: '${cmd}'. Type 'help' for available Azure CLI commands.`;
    }

    if (cmd) {
      setTerminalLogs((prev) => [...prev, `user@Azure:~$ ${terminalCommand}`, response]);
      setTerminalCommand('');
    }
  };

  return (
    <>
      {/* 1. AZURE PORTAL GLOBAL TOP HEADER (Authentic portal.azure.com deep navy bar in all modes) */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#001833] border-b border-[#0078D4]/40 shadow-md">
        <div className="flex items-center justify-between h-12 px-3 sm:px-4 text-slate-100 select-none">
          
          {/* Left: Azure Cloud Logo & Brand Title */}
          <div className="flex items-center gap-3">
            {/* Hamburger / Sidebar Toggle */}
            <button
              type="button"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              title="Show Azure Resources Navigation Blade"
              className="p-1.5 hover:bg-[#002b5c] rounded text-slate-200 hover:text-white transition-colors cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Azure Logo Symbol & Brand */}
            <a
              href="#hero"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('#hero');
              }}
              className="flex items-center gap-2 group cursor-pointer"
            >
              {/* Azure Cloud Icon SVG */}
              <div className="w-5 h-5 flex items-center justify-center">
                <svg viewBox="0 0 96 96" className="w-5 h-5 fill-[#0078D4]">
                  <path d="M57.6 12L32 60h24l-8 24 38.4-48H60.8l8-24z" fill="#0078D4" opacity="0.3"/>
                  <path d="M26.4 12L7.2 60H36l5.6-14.4-11.2-4.8L40 12z" fill="#0078D4"/>
                  <path d="M60.8 12L36 60h24l-8 24 38.4-48H60.8z" fill="#29b6f6"/>
                </svg>
              </div>
              <span className="font-semibold text-sm tracking-tight text-white flex items-center gap-1.5">
                MG Portal
              </span>
            </a>

            {/* Breadcrumb Environment Indicator */}
            <div className="hidden md:flex items-center text-xs text-slate-300 border-l border-slate-700 pl-3">
              <span className="text-slate-400">Manoj Goje</span>
              <span className="mx-1.5 text-slate-600">/</span>
              <span className="font-mono text-cyan-300 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Data-Ops-Production
              </span>
            </div>
          </div>

          {/* Center: Global Search Bar (Azure Portal Standard) */}
          <div className="flex-1 max-w-md mx-3 sm:mx-6 hidden sm:block">
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="w-full flex items-center justify-between px-3 py-1 bg-[#001024] hover:bg-[#002447] border border-[#1b3c73] hover:border-[#0078D4] rounded text-xs text-slate-300 transition-all cursor-pointer shadow-inner"
            >
              <div className="flex items-center gap-2">
                <Search className="w-3.5 h-3.5 text-[#0078D4]" />
                <span className="truncate">Search resources, services, and docs (G+/)</span>
              </div>
              <kbd className="hidden lg:inline text-[10px] font-mono bg-[#0f2244] border border-[#1b3c73] px-1.5 py-0.5 rounded text-slate-400">
                Alt + S
              </kbd>
            </button>
          </div>

          {/* Right: Cloud Shell, Theme Toggle, Notifications, User Badge */}
          <div className="flex items-center gap-1 sm:gap-2">
            
            {/* Mobile Search Button */}
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              title="Search"
              className="sm:hidden p-1.5 hover:bg-[#002b5c] rounded text-slate-200"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* ONLY ONE THEME TOGGLE BUTTON (Light Mode <-> Dark Mode) */}
            <button
              type="button"
              onClick={toggleDarkMode}
              title={darkMode ? 'Switch to Light Mode (Azure White + Blue)' : 'Switch to Dark Mode (Azure Midnight + Blue)'}
              className="p-1.5 rounded hover:bg-[#002b5c] text-slate-200 hover:text-white transition-colors cursor-pointer flex items-center gap-1 text-xs"
              aria-label="Toggle Light and Dark Theme"
            >
              {darkMode ? (
                <Sun className="w-4 h-4 text-amber-300 animate-in spin-in-180 duration-200" />
              ) : (
                <Moon className="w-4 h-4 text-cyan-300 animate-in spin-in-180 duration-200" />
              )}
              <span className="hidden md:inline text-[11px] font-mono text-slate-300">
                {darkMode ? 'Light' : 'Dark'}
              </span>
            </button>

            {/* Cloud Shell Terminal Button */}
            <button
              type="button"
              onClick={() => setCloudShellOpen(!cloudShellOpen)}
              title="Open Azure Cloud Shell (CLI)"
              className={`p-1.5 rounded transition-colors flex items-center gap-1 text-xs font-mono cursor-pointer ${
                cloudShellOpen
                  ? 'bg-[#0078D4] text-white shadow-sm'
                  : 'hover:bg-[#002b5c] text-slate-200'
              }`}
            >
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span className="hidden xl:inline text-[11px]">Cloud Shell</span>
            </button>

            {/* Directory / Subscriptions Pill */}
            <div className="hidden lg:flex items-center text-[11px] font-mono text-slate-300 bg-[#001024] border border-[#1b3c73] px-2 py-0.5 rounded">
              <span className="text-slate-400 mr-1.5">Sub:</span>
              <span className="text-cyan-300 font-semibold">prod-dataops-001</span>
            </div>

            {/* Notifications Bell with Dropdown */}
            <div className="relative" ref={notificationsRef}>
              <button
                type="button"
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                title="Notifications"
                className="p-1.5 hover:bg-[#002b5c] rounded text-slate-200 relative cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-[#0078D4] rounded-full ring-2 ring-[#001833] animate-pulse" />
              </button>

              {notificationsOpen && (
                <div className={`absolute right-0 mt-2 w-80 sm:w-96 rounded-lg shadow-2xl z-50 p-3 animate-in fade-in zoom-in-95 border ${
                  darkMode
                    ? 'bg-[#0d1b32] border-[#1b3c73]'
                    : 'bg-white border-[#d2e3fc] text-slate-800'
                }`}>
                  <div className={`flex items-center justify-between pb-2 border-b text-xs font-semibold ${
                    darkMode ? 'border-[#1b3c73] text-slate-200' : 'border-slate-200 text-slate-900'
                  }`}>
                    <span className="flex items-center gap-1.5">
                      <Bell className="w-3.5 h-3.5 text-[#0078D4]" />
                      <span>Azure Activity Notifications (3)</span>
                    </span>
                    <span className="text-[10px] font-mono text-emerald-500 font-bold">All Healthy</span>
                  </div>

                  <div className={`divide-y max-h-72 overflow-y-auto mt-2 text-xs ${
                    darkMode ? 'divide-[#1b3c73]/60' : 'divide-slate-100'
                  }`}>
                    <div className="py-2 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className={`font-semibold flex items-center gap-1 ${
                          darkMode ? 'text-slate-100' : 'text-slate-900'
                        }`}>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                          Medallion Pipeline Ingestion Succeeded
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">12m ago</span>
                      </div>
                      <p className={`text-[11px] ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                        ADF Pipeline executed 2.4M raw event rows into Delta Silver/Gold tables with ACID parity.
                      </p>
                    </div>

                    <div className="py-2 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className={`font-semibold flex items-center gap-1 ${
                          darkMode ? 'text-slate-100' : 'text-slate-900'
                        }`}>
                          <ShieldCheck className="w-3.5 h-3.5 text-[#0078D4]" />
                          Advisor: Verified Certifications
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">Today</span>
                      </div>
                      <p className={`text-[11px] ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                        DP-203, Databricks Associate, and AZ-104 verified via official credential links.
                      </p>
                    </div>

                    <div className="py-2 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className={`font-semibold flex items-center gap-1 ${
                          darkMode ? 'text-slate-100' : 'text-slate-900'
                        }`}>
                          <Activity className="w-3.5 h-3.5 text-blue-500" />
                          SLA Incident Diagnosis Rate +40%
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">Cognizant</span>
                      </div>
                      <p className={`text-[11px] ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                        Production telemetry metrics confirmed 30% reduction in data discrepancies across enterprise clusters.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Help / Feedback Icon */}
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('#contact');
              }}
              title="Help & Support"
              className="p-1.5 hover:bg-[#002b5c] rounded text-slate-200 transition-colors"
            >
              <HelpCircle className="w-4 h-4" />
            </a>

            {/* User Profile Badge (Azure Account Avatar) */}
            <div className="flex items-center gap-2 pl-1.5 border-l border-slate-700">
              <div className="w-7 h-7 rounded-full bg-[#0078D4] flex items-center justify-center text-[11px] font-bold text-white shadow-sm ring-1 ring-white/20">
                MG
              </div>
              <div className="hidden xl:block text-left text-xs leading-none">
                <span className="font-semibold text-slate-100 block">{PERSONAL_INFO.name}</span>
                <span className="text-[10px] font-mono text-slate-300">Data Operations Engineer</span>
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* 2. AZURE COMMAND BAR / BREADCRUMBS RIBBON (Sub-header) */}
      <nav className={`fixed top-12 left-0 right-0 z-40 py-1.5 px-3 sm:px-6 flex items-center justify-between text-xs overflow-x-auto shadow-sm backdrop-blur-md transition-colors border-b ${
        darkMode
          ? 'bg-[#081528] border-[#1b3c73]'
          : 'bg-white border-[#d2e3fc] text-slate-800'
      }`}>
        
        {/* Breadcrumb Path */}
        <div className={`flex items-center gap-1.5 font-mono text-[11px] whitespace-nowrap ${
          darkMode ? 'text-slate-300' : 'text-slate-600'
        }`}>
          <button
            onClick={() => scrollToSection('#hero')}
            className={`hover:text-[#0078D4] transition-colors cursor-pointer ${
              darkMode ? 'text-slate-400' : 'text-slate-500'
            }`}
          >
            Home
          </button>
          <ChevronRight className="w-3 h-3 text-slate-400" />
          <button
            onClick={() => scrollToSection('#skills')}
            className={`hover:text-[#0078D4] transition-colors cursor-pointer ${
              darkMode ? 'text-slate-400' : 'text-slate-500'
            }`}
          >
            Subscriptions
          </button>
          <ChevronRight className="w-3 h-3 text-slate-400" />
          <span className={`font-semibold ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`}>
            rg-manoj-lakehouse-dataops
          </span>
        </div>

        {/* Action Command Buttons */}
        <div className="flex items-center gap-1.5 whitespace-nowrap ml-4">
          <button
            type="button"
            onClick={() => scrollToSection('#contact')}
            className="flex items-center gap-1 px-2.5 py-1 bg-[#0078D4] hover:bg-[#106ebe] text-white rounded font-medium text-xs transition-colors shadow-sm cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Connect / Hire</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (onRunPipeline) onRunPipeline();
              scrollToSection('#projects');
            }}
            className={`hidden sm:flex items-center gap-1 px-2.5 py-1 rounded font-medium text-xs transition-colors border cursor-pointer ${
              darkMode
                ? 'bg-[#0f2244] hover:bg-[#163566] text-cyan-300 border-[#1b3c73]'
                : 'bg-[#f0f6ff] hover:bg-[#e0edff] text-[#0078D4] border-[#bfdbfe]'
            }`}
          >
            <Play className="w-3 h-3 text-emerald-500" />
            <span>Run Pipeline</span>
          </button>

          <button
            type="button"
            onClick={onOpenResume}
            className={`flex items-center gap-1 px-2.5 py-1 rounded font-medium text-xs transition-colors border cursor-pointer ${
              darkMode
                ? 'bg-[#0f2244] hover:bg-[#163566] text-slate-200 border-[#1b3c73]'
                : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300'
            }`}
          >
            <FileDown className="w-3.5 h-3.5 text-[#0078D4]" />
            <span>View Resume</span>
          </button>

          <button
            type="button"
            onClick={() => scrollToSection('#certifications')}
            className={`hidden md:flex items-center gap-1 px-2.5 py-1 rounded font-medium text-xs transition-colors border cursor-pointer ${
              darkMode
                ? 'bg-[#0f2244] hover:bg-[#163566] text-slate-200 border-[#1b3c73]'
                : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#0078D4]" />
            <span>Advisor (3 Certs)</span>
          </button>
        </div>
      </nav>

      {/* 3. AZURE PORTAL COLLAPSIBLE SIDEBAR / BLADE (Left Drawer) */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
            onClick={() => setSidebarOpen(false)}
          />

          {/* Left Navigation Blade */}
          <div className={`relative w-72 sm:w-80 h-full shadow-2xl flex flex-col justify-between z-10 animate-in slide-in-from-left duration-200 border-r ${
            darkMode
              ? 'bg-[#081528] border-[#1b3c73]'
              : 'bg-white border-[#d2e3fc] text-slate-800'
          }`}>
            <div>
              {/* Blade Header */}
              <div className="flex items-center justify-between p-4 border-b border-[#1b3c73] bg-[#001833]">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded bg-[#0078D4] flex items-center justify-center text-white text-xs font-bold">
                    ⊞
                  </div>
                  <div>
                    <h2 className="text-sm font-semibold text-white">MG Portal Menu</h2>
                    <p className="text-[10px] font-mono text-cyan-300">Data Ops Workspace</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSidebarOpen(false)}
                  className="p-1 hover:bg-[#002b5c] rounded text-slate-300 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Favorites / Resource List */}
              <div className="p-3">
                <div className={`text-[10px] font-mono uppercase tracking-wider px-2 py-1 mb-1 ${
                  darkMode ? 'text-slate-400' : 'text-slate-500'
                }`}>
                  Favorites &amp; Services
                </div>
                <div className="space-y-1">
                  {navLinks.map((link) => {
                    const Icon = link.icon;
                    const isActive = activeSection === link.href.replace('#', '');
                    return (
                      <button
                        key={link.name}
                        onClick={() => scrollToSection(link.href)}
                        className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all text-left cursor-pointer ${
                          isActive
                            ? darkMode
                              ? 'bg-[#0078D4]/25 text-white border-l-4 border-[#0078D4] pl-2 font-semibold'
                              : 'bg-[#e0edff] text-[#0078D4] border-l-4 border-[#0078D4] pl-2 font-semibold'
                            : darkMode
                              ? 'text-slate-300 hover:bg-[#0f2244] hover:text-white'
                              : 'text-slate-700 hover:bg-[#f0f6ff] hover:text-[#0078D4]'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon className={`w-4 h-4 ${
                            isActive
                              ? darkMode ? 'text-cyan-300' : 'text-[#0078D4]'
                              : darkMode ? 'text-slate-400' : 'text-slate-500'
                          }`} />
                          <span>{link.name}</span>
                        </div>
                        <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                          darkMode ? 'text-slate-400 bg-[#001024]' : 'text-slate-500 bg-slate-100'
                        }`}>
                          {link.tag}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Sidebar Bottom Subscription Status */}
            <div className={`p-4 border-t space-y-2 ${
              darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#f8fafc] border-[#e2e8f0]'
            }`}>
              <div className="flex items-center justify-between text-xs">
                <span className={darkMode ? 'text-slate-400' : 'text-slate-600'}>Environment:</span>
                <span className="font-mono text-emerald-500 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  100% Operational
                </span>
              </div>
              <div className={`flex items-center justify-between text-[11px] font-mono ${
                darkMode ? 'text-slate-400' : 'text-slate-600'
              }`}>
                <span>Location:</span>
                <span className={darkMode ? 'text-slate-200' : 'text-slate-800'}>Central India (Pune)</span>
              </div>
              <div className={`flex items-center justify-between text-[11px] font-mono ${
                darkMode ? 'text-slate-400' : 'text-slate-600'
              }`}>
                <span>SLA Level:</span>
                <span className={darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}>99.9% Production</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. AZURE GLOBAL SEARCH MODAL (Triggered by Alt+S / Search Bar) */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setSearchOpen(false)}
          />
          <div className={`relative w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden z-10 animate-in zoom-in-95 duration-150 border ${
            darkMode
              ? 'bg-[#0d1b32] border-[#1b3c73]'
              : 'bg-white border-[#d2e3fc]'
          }`}>
            {/* Search Input Bar */}
            <div className="flex items-center px-4 py-3 border-b border-[#1b3c73] bg-[#001833]">
              <Search className="w-5 h-5 text-[#0078D4] mr-3" />
              <input
                ref={searchInputRef}
                autoFocus
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search skills, certs, experience, pipelines, contact..."
                className="w-full bg-transparent text-sm text-slate-100 placeholder:text-slate-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="p-1 hover:bg-[#002b5c] rounded text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Results Container */}
            <div className={`max-h-80 overflow-y-auto p-2 divide-y ${
              darkMode ? 'divide-[#1b3c73]/50' : 'divide-slate-100'
            }`}>
              {filteredSearch.length > 0 ? (
                filteredSearch.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      if (item.action) {
                        item.action();
                        setSearchOpen(false);
                      } else if (item.section) {
                        scrollToSection(item.section);
                      }
                    }}
                    className={`flex items-center justify-between p-2.5 rounded-lg transition-colors cursor-pointer ${
                      darkMode
                        ? 'hover:bg-[#0f2244]'
                        : 'hover:bg-[#f0f6ff]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Sparkles className="w-4 h-4 text-[#0078D4]" />
                      <div>
                        <div className={`text-xs font-semibold ${
                          darkMode ? 'text-slate-100' : 'text-slate-900'
                        }`}>{item.title}</div>
                        <div className={`text-[10px] font-mono ${
                          darkMode ? 'text-slate-400' : 'text-slate-500'
                        }`}>{item.category}</div>
                      </div>
                    </div>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                      darkMode
                        ? 'text-cyan-300 bg-[#001024] border-[#1b3c73]'
                        : 'text-[#0078D4] bg-[#f0f6ff] border-[#bfdbfe]'
                    }`}>
                      Jump &rarr;
                    </span>
                  </div>
                ))
              ) : (
                <div className={`p-6 text-center text-xs font-mono ${
                  darkMode ? 'text-slate-400' : 'text-slate-500'
                }`}>
                  No matching Azure resource found for "{searchQuery}".
                </div>
              )}
            </div>

            <div className={`p-2.5 border-t flex items-center justify-between text-[11px] font-mono ${
              darkMode
                ? 'bg-[#001024] border-[#1b3c73] text-slate-400'
                : 'bg-[#f8fafc] border-[#e2e8f0] text-slate-600'
            }`}>
              <span>Tip: Press ESC or click outside to dismiss</span>
              <span className={darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}>Azure Resource Finder</span>
            </div>
          </div>
        </div>
      )}

      {/* 5. AZURE CLOUD SHELL TERMINAL DRAWER (Bottom Drawer) */}
      {cloudShellOpen && (
        <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#001024] border-t-2 border-[#0078D4] shadow-2xl h-72 flex flex-col animate-in slide-in-from-bottom duration-200 font-mono text-xs">
          {/* Terminal Top Bar */}
          <div className="flex items-center justify-between px-4 py-2 bg-[#001833] border-b border-[#1b3c73]">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span className="font-semibold text-slate-200">Azure Cloud Shell &bull; Bash</span>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-700/50 px-1.5 py-0.5 rounded">
                CONNECTED
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setTerminalLogs(['Azure Cloud Shell reset. Type "help" for options.'])}
                title="Restart Session"
                className="p-1 hover:bg-[#002b5c] rounded text-slate-400 hover:text-white"
              >
                <RotateCw className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setCloudShellOpen(false)}
                className="p-1 hover:bg-[#002b5c] rounded text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Terminal Logs Output */}
          <div className="flex-1 p-3 overflow-y-auto space-y-1 text-slate-300">
            {terminalLogs.map((log, idx) => (
              <div key={idx} className="whitespace-pre-wrap leading-relaxed">
                {log.startsWith('user@') ? (
                  <span className="text-cyan-300 font-bold">{log}</span>
                ) : log.startsWith('[✓]') ? (
                  <span className="text-emerald-400">{log}</span>
                ) : (
                  <span>{log}</span>
                )}
              </div>
            ))}
          </div>

          {/* Terminal Input Form */}
          <form onSubmit={handleTerminalSubmit} className="flex items-center px-3 py-2 bg-[#000d1a] border-t border-[#1b3c73]">
            <span className="text-emerald-400 font-bold mr-2">user@Azure:~$</span>
            <input
              type="text"
              value={terminalCommand}
              onChange={(e) => setTerminalCommand(e.target.value)}
              placeholder="type 'help', 'az cert list', 'az pipeline run', 'az resume'..."
              className="flex-1 bg-transparent text-slate-100 placeholder:text-slate-600 focus:outline-none"
            />
            <button type="submit" className="text-xs px-2 py-0.5 bg-[#0078D4] text-white rounded">
              Execute
            </button>
          </form>
        </div>
      )}
    </>
  );
};

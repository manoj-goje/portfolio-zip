import React, { useState } from 'react';
import { TECHNICAL_SKILLS } from '../data/portfolioData';
import { TechIcon } from './TechIcon';
import { Cloud, Code2, GitBranch, Database, Sparkles, Layers } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const TechSkills: React.FC = () => {
  const { darkMode } = useTheme();
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Azure Resources', icon: Sparkles, count: TECHNICAL_SKILLS.length },
    { id: 'cloud', label: 'Azure Cloud & Services', icon: Cloud, count: TECHNICAL_SKILLS.filter(s => s.category === 'cloud').length },
    { id: 'languages', label: 'Languages & Spark', icon: Code2, count: TECHNICAL_SKILLS.filter(s => s.category === 'languages').length },
    { id: 'mlops', label: 'MLOps & DevOps', icon: GitBranch, count: TECHNICAL_SKILLS.filter(s => s.category === 'mlops').length },
    { id: 'data_eng', label: 'Data Engineering', icon: Database, count: TECHNICAL_SKILLS.filter(s => s.category === 'data_eng').length },
  ];

  const filteredSkills = activeCategory === 'all'
    ? TECHNICAL_SKILLS
    : TECHNICAL_SKILLS.filter((s) => s.category === activeCategory);

  return (
    <section id="skills" className={`py-16 relative transition-colors ${
      darkMode ? 'bg-[#080f1e]' : 'bg-[#f4f8fc]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono mb-2 ${
            darkMode
              ? 'border-[#0078D4]/40 bg-[#0078D4]/10 text-cyan-300'
              : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
          }`}>
            <span>RESOURCES.CATALOG / SERVICES &amp; STACK</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Technical Skills &amp; Stack
          </h2>
          <p className={`text-sm sm:text-base mt-2 ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Official technology ecosystem utilized for scalable Azure data pipelines, Lakehouse architecture, and real-time operations.
          </p>
          <div className="w-16 h-1 bg-[#0078D4] mx-auto mt-3 rounded-full" />
        </div>

        {/* Filter Category Tabs (Azure Blade Tabs) */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-md text-xs font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#0078D4] text-white font-semibold shadow-md'
                    : darkMode
                      ? 'bg-[#0d1b32] text-slate-300 hover:text-white hover:bg-[#163566] border border-[#1b3c73]'
                      : 'bg-white text-slate-700 hover:text-[#0078D4] hover:bg-slate-50 border border-slate-200'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}`} />
                <span>{cat.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                    isActive
                      ? 'bg-black/30 text-white'
                      : darkMode
                        ? 'bg-[#001024] text-slate-400'
                        : 'bg-slate-100 text-slate-500'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Skills Resource Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
          {filteredSkills.map((skill) => {
            return (
              <div
                key={skill.name}
                className={`group relative flex flex-col items-center text-center p-4 rounded-xl border transition-all duration-200 hover:-translate-y-1 shadow-md ${
                  darkMode
                    ? 'border-[#1b3c73] bg-[#0d1b32] hover:bg-[#0f2244] hover:border-[#0078D4]'
                    : 'border-[#d2e3fc] bg-white hover:border-[#0078D4] hover:shadow-lg'
                }`}
              >
                {/* Tech Logo */}
                <div className={`w-12 h-12 flex items-center justify-center rounded-xl border p-2.5 mb-3 group-hover:scale-105 transition-transform ${
                  darkMode
                    ? 'bg-[#001024] border-[#1b3c73]'
                    : 'bg-[#f0f6ff] border-[#bfdbfe]'
                }`}>
                  <TechIcon name={skill.iconKey || skill.name} className="w-7 h-7" />
                </div>

                {/* Skill Name */}
                <h3 className={`font-bold text-xs sm:text-sm line-clamp-1 transition-colors ${
                  darkMode
                    ? 'text-slate-100 group-hover:text-cyan-300'
                    : 'text-slate-900 group-hover:text-[#0078D4]'
                }`}>
                  {skill.name}
                </h3>

                {/* Level / Tag */}
                {skill.experienceLevel && (
                  <span className={`text-[10px] font-mono mt-1 px-2 py-0.5 rounded border ${
                    darkMode
                      ? 'text-cyan-300 bg-[#001024] border-[#1b3c73]'
                      : 'text-[#0078D4] bg-[#eff6ff] border-[#bfdbfe]'
                  }`}>
                    {skill.experienceLevel}
                  </span>
                )}

                {/* Description */}
                <p className={`text-[11px] line-clamp-2 mt-2 leading-relaxed font-sans ${
                  darkMode ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  {skill.description}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

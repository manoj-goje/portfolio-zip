import React from 'react';
import { CERTIFICATIONS_LIST } from '../data/portfolioData';
import { TechIcon } from './TechIcon';
import { Award, CheckCircle2, ShieldCheck, ExternalLink, Sparkles } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const Certifications: React.FC = () => {
  const { darkMode } = useTheme();

  return (
    <section id="certifications" className={`py-16 border-t relative transition-colors ${
      darkMode ? 'bg-[#081528] border-[#1b3c73]' : 'bg-[#ffffff] border-[#d2e3fc]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono mb-2 ${
            darkMode
              ? 'border-[#0078D4]/40 bg-[#0078D4]/10 text-cyan-300'
              : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
          }`}>
            <span>ADVISOR.INSIGHTS / CERTIFIED ARCHITECTURE</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Industry Certifications
          </h2>
          <p className={`text-sm sm:text-base mt-2 ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Verified expertise in enterprise cloud architecture, lakehouse operations, and data engineering.
          </p>
          <div className="w-16 h-1 bg-[#0078D4] mx-auto mt-3 rounded-full" />
        </div>

        {/* Certifications Badge / Card Grid (4 Cards) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {CERTIFICATIONS_LIST.map((cert, index) => {
            return (
              <div
                key={index}
                className={`group relative flex flex-col justify-between p-5 sm:p-6 rounded-xl border transition-all duration-300 shadow-xl hover:-translate-y-1 ${
                  darkMode
                    ? 'border-[#1b3c73] bg-[#0d1b32] hover:border-[#0078D4]'
                    : 'border-[#d2e3fc] bg-white hover:border-[#0078D4] hover:shadow-2xl'
                }`}
              >
                <div>
                  {/* Top Bar: Issuer Logo + Verified Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl border p-2.5 flex items-center justify-center group-hover:scale-105 transition-transform ${
                      darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#f0f6ff] border-[#bfdbfe]'
                    }`}>
                      <TechIcon name={cert.iconKey} className="w-7 h-7" />
                    </div>

                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-mono font-semibold bg-emerald-950/20 text-emerald-500 border border-emerald-500/30">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>{cert.status}</span>
                    </div>
                  </div>

                  {/* Cert Code Badge */}
                  <span className={`inline-block text-[11px] font-mono font-bold px-2.5 py-0.5 rounded mb-2 border ${
                    darkMode
                      ? 'text-cyan-300 bg-[#001024] border-[#1b3c73]'
                      : 'text-[#0078D4] bg-[#eff6ff] border-[#bfdbfe]'
                  }`}>
                    {cert.code}
                  </span>

                  {/* Certification Name */}
                  <h3 className={`text-base sm:text-lg font-bold transition-colors leading-snug ${
                    darkMode
                      ? 'text-white group-hover:text-cyan-300'
                      : 'text-slate-900 group-hover:text-[#0078D4]'
                  }`}>
                    {cert.name}
                  </h3>

                  {/* Issuer */}
                  <p className={`text-xs font-mono mt-1 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    Issuer: <span className={`font-semibold ${darkMode ? 'text-slate-200' : 'text-slate-800'}`}>{cert.issuer}</span>
                  </p>

                  {/* Description */}
                  <p className={`text-xs mt-3 leading-relaxed font-sans ${
                    darkMode ? 'text-slate-300' : 'text-slate-600'
                  }`}>
                    {cert.description}
                  </p>
                </div>

                {/* Bottom Verification Action & Link */}
                <div className={`mt-5 pt-3 border-t flex items-center justify-between gap-2 ${
                  darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
                }`}>
                  <span className="flex items-center gap-1 font-mono text-[11px] text-slate-400">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Official ID</span>
                  </span>

                  {cert.credentialUrl ? (
                    <a
                      href={cert.credentialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold font-mono bg-[#0078D4] hover:bg-[#106ebe] text-white transition-all duration-200 shadow-sm"
                    >
                      <span>Verify</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  ) : (
                    <span className={`text-[10px] font-mono ${darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}`}>Verified</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

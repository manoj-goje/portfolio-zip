import React from 'react';
import { EDUCATION_DATA } from '../data/portfolioData';
import { GraduationCap, Calendar, MapPin, CheckCircle2 } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const Education: React.FC = () => {
  const { darkMode } = useTheme();

  return (
    <section id="education" className={`py-16 relative transition-colors ${
      darkMode ? 'bg-[#080f1e]' : 'bg-[#f4f8fc]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono mb-2 ${
            darkMode
              ? 'border-[#0078D4]/40 bg-[#0078D4]/10 text-cyan-300'
              : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
          }`}>
            <span>ACADEMIC.FOUNDATIONS / EDUCATION</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Education &amp; Academic Background
          </h2>
          <p className={`text-sm sm:text-base mt-2 ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Solid foundations in computer systems, algorithms, distributed computing, and database management.
          </p>
          <div className="w-16 h-1 bg-[#0078D4] mx-auto mt-3 rounded-full" />
        </div>

        {/* Education Card */}
        <div className="max-w-3xl mx-auto">
          <div className={`rounded-xl border p-6 sm:p-7 shadow-xl transition-all ${
            darkMode
              ? 'bg-[#0d1b32] border-[#1b3c73] hover:border-[#0078D4]'
              : 'bg-white border-[#d2e3fc] hover:border-[#0078D4] hover:shadow-2xl'
          }`}>
            
            {/* Top Bar */}
            <div className={`flex flex-wrap items-start justify-between gap-4 pb-4 border-b ${
              darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
            }`}>
              <div className="flex items-start gap-3.5">
                <div className={`w-11 h-11 rounded-lg border flex items-center justify-center flex-shrink-0 mt-0.5 ${
                  darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#eff6ff] border-[#bfdbfe]'
                }`}>
                  <GraduationCap className={`w-6 h-6 ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`} />
                </div>
                <div>
                  <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-semibold mb-1.5 border ${
                    darkMode
                      ? 'bg-[#001024] text-cyan-300 border-[#1b3c73]'
                      : 'bg-[#eff6ff] text-[#0078D4] border-[#bfdbfe]'
                  }`}>
                    BACHELOR OF ENGINEERING
                  </span>
                  <h3 className={`text-xl sm:text-2xl font-bold ${
                    darkMode ? 'text-white' : 'text-slate-900'
                  }`}>
                    {EDUCATION_DATA.degree}
                  </h3>
                  <p className={`text-sm sm:text-base font-semibold ${
                    darkMode ? 'text-cyan-300' : 'text-[#0078D4]'
                  }`}>
                    {EDUCATION_DATA.field}
                  </p>
                  <p className={`text-xs sm:text-sm mt-0.5 ${
                    darkMode ? 'text-slate-300' : 'text-slate-600'
                  }`}>
                    {EDUCATION_DATA.institution}
                  </p>
                </div>
              </div>

              {/* Date & Location */}
              <div className={`flex flex-col sm:items-end gap-1.5 text-xs font-mono ${
                darkMode ? 'text-slate-300' : 'text-slate-600'
              }`}>
                <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded border ${
                  darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#f8fafc] border-slate-200'
                }`}>
                  <Calendar className="w-3.5 h-3.5 text-[#0078D4]" />
                  <span>{EDUCATION_DATA.period}</span>
                </div>
                <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded border ${
                  darkMode ? 'bg-[#001024] border-[#1b3c73] text-slate-400' : 'bg-[#f8fafc] border-slate-200 text-slate-500'
                }`}>
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{EDUCATION_DATA.location}</span>
                </div>
              </div>
            </div>

            {/* Academic Highlights */}
            <div className="mt-5 space-y-2.5 font-sans">
              <span className={`text-xs font-mono uppercase tracking-wider block ${
                darkMode ? 'text-slate-400' : 'text-slate-500'
              }`}>
                Coursework &amp; Key Focus Areas:
              </span>
              {EDUCATION_DATA.highlights.map((highlight, idx) => (
                <div key={idx} className={`flex items-start gap-2.5 text-xs sm:text-sm ${
                  darkMode ? 'text-slate-300' : 'text-slate-700'
                }`}>
                  <CheckCircle2 className={`w-4 h-4 flex-shrink-0 mt-0.5 ${
                    darkMode ? 'text-cyan-400' : 'text-[#0078D4]'
                  }`} />
                  <span className="leading-relaxed">{highlight}</span>
                </div>
              ))}
            </div>

            {/* Relevant Coursework Badges */}
            <div className={`mt-6 pt-4 border-t flex flex-wrap items-center gap-2 ${
              darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
            }`}>
              <span className={`text-xs font-mono mr-1 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Key Modules:</span>
              {[
                'Database Management Systems',
                'Distributed Systems',
                'Data Structures & Algorithms',
                'Computer Networks',
                'Cloud Computing',
                'Operating Systems',
              ].map((tag, idx) => (
                <span
                  key={idx}
                  className={`text-xs font-mono px-2.5 py-1 rounded border ${
                    darkMode
                      ? 'bg-[#001024] text-slate-300 border-[#1b3c73]'
                      : 'bg-[#f8fafc] text-slate-700 border-slate-200'
                  }`}
                >
                  {tag}
                </span>
              ))}
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};

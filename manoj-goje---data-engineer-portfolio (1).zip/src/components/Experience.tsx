import React from 'react';
import { EXPERIENCE_LIST } from '../data/portfolioData';
import { Calendar, MapPin, CheckCircle2, Server, Activity, ShieldCheck } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const Experience: React.FC = () => {
  const { darkMode } = useTheme();

  return (
    <section id="experience" className={`py-16 border-t relative transition-colors ${
      darkMode ? 'bg-[#081528] border-[#1b3c73]' : 'bg-[#ffffff] border-[#d2e3fc]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono mb-2 ${
            darkMode
              ? 'border-[#0078D4]/40 bg-[#0078D4]/10 text-cyan-300'
              : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
          }`}>
            <span>INSIGHTS.ACTIVITY / LOGS &amp; SERVICE HEALTH</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Professional Experience
          </h2>
          <p className={`text-sm sm:text-base mt-2 ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Demonstrated impact across high-volume GIS &amp; enterprise data operations.
          </p>
          <div className="w-16 h-1 bg-[#0078D4] mx-auto mt-3 rounded-full" />
        </div>

        {/* Timeline Container */}
        <div className="max-w-4xl mx-auto relative">
          
          {/* Vertical Spine Line */}
          <div className={`absolute left-4 sm:left-8 top-3 bottom-3 w-0.5 ${
            darkMode
              ? 'bg-gradient-to-b from-[#0078D4] via-[#29b6f6] to-[#1b3c73]'
              : 'bg-gradient-to-b from-[#0078D4] via-[#60a5fa] to-[#d2e3fc]'
          }`} />

          {EXPERIENCE_LIST.map((exp, index) => {
            return (
              <div key={index} className="relative pl-12 sm:pl-20 pb-8">
                
                {/* Timeline Pulsing Node */}
                <div className={`absolute left-2.5 sm:left-6.5 top-1.5 -translate-x-1/2 w-5 h-5 rounded-full border-2 border-[#0078D4] flex items-center justify-center shadow-lg shadow-[#0078D4]/40 ${
                  darkMode ? 'bg-[#001024]' : 'bg-white'
                }`}>
                  <div className="w-2 h-2 rounded-full bg-[#0078D4] animate-ping" />
                </div>

                {/* Experience Card */}
                <div className={`rounded-xl border p-6 sm:p-7 shadow-lg transition-all ${
                  darkMode
                    ? 'bg-[#0d1b32] border-[#1b3c73] hover:border-[#0078D4]'
                    : 'bg-white border-[#d2e3fc] hover:border-[#0078D4] hover:shadow-xl'
                }`}>
                  
                  {/* Top Bar: Role & Company */}
                  <div className={`flex flex-wrap items-start justify-between gap-3 pb-4 border-b ${
                    darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
                  }`}>
                    <div>
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-mono font-semibold border ${
                          darkMode
                            ? 'bg-[#0078D4]/20 text-cyan-300 border-[#0078D4]/40'
                            : 'bg-[#eff6ff] text-[#0078D4] border-[#bfdbfe]'
                        }`}>
                          ENTERPRISE ROLE
                        </span>
                        <span className="text-[10px] font-mono text-emerald-500 bg-emerald-950/20 px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1">
                          <Activity className="w-3 h-3 animate-pulse" />
                          SLA ACTIVE
                        </span>
                      </div>
                      <h3 className={`text-xl sm:text-2xl font-bold ${
                        darkMode ? 'text-white' : 'text-slate-900'
                      }`}>
                        {exp.role}
                      </h3>
                      <p className={`text-base font-semibold mt-0.5 ${
                        darkMode ? 'text-cyan-300' : 'text-[#0078D4]'
                      }`}>
                        {exp.company}
                      </p>
                    </div>

                    {/* Period & Location Pills */}
                    <div className={`flex flex-col sm:items-end gap-1 text-xs font-mono ${
                      darkMode ? 'text-slate-300' : 'text-slate-600'
                    }`}>
                      <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded border ${
                        darkMode
                          ? 'bg-[#001024] border-[#1b3c73]'
                          : 'bg-[#f8fafc] border-slate-200'
                      }`}>
                        <Calendar className="w-3.5 h-3.5 text-[#0078D4]" />
                        <span>{exp.period}</span>
                      </div>
                      <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded border ${
                        darkMode
                          ? 'bg-[#001024] border-[#1b3c73] text-slate-400'
                          : 'bg-[#f8fafc] border-slate-200 text-slate-500'
                      }`}>
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span>{exp.location}</span>
                      </div>
                    </div>
                  </div>

                  {/* Summary */}
                  <p className={`text-sm mt-4 leading-relaxed font-sans ${
                    darkMode ? 'text-slate-200' : 'text-slate-700'
                  }`}>
                    {exp.summary}
                  </p>

                  {/* Key Responsibilities & Bullet Points */}
                  <div className="mt-5 space-y-3 font-sans">
                    {exp.bullets.map((bullet, bIdx) => (
                      <div key={bIdx} className={`flex items-start gap-2.5 text-xs sm:text-sm ${
                        darkMode ? 'text-slate-300' : 'text-slate-700'
                      }`}>
                        <CheckCircle2 className={`w-4 h-4 flex-shrink-0 mt-0.5 ${
                          darkMode ? 'text-cyan-400' : 'text-[#0078D4]'
                        }`} />
                        <span className="leading-relaxed">{bullet}</span>
                      </div>
                    ))}
                  </div>

                  {/* Impact Metrics Bar */}
                  <div className={`grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6 pt-5 border-t ${
                    darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
                  }`}>
                    {exp.metrics.map((m, mIdx) => (
                      <div
                        key={mIdx}
                        className={`p-3 rounded-lg border text-center ${
                          darkMode
                            ? 'bg-[#001024] border-[#1b3c73]'
                            : 'bg-[#f0f6ff] border-[#bfdbfe]'
                        }`}
                      >
                        <span className={`text-xl font-extrabold font-mono block ${
                          darkMode ? 'text-cyan-300' : 'text-[#0078D4]'
                        }`}>
                          {m.value}
                        </span>
                        <span className={`text-[11px] font-medium ${
                          darkMode ? 'text-slate-400' : 'text-slate-600'
                        }`}>
                          {m.label}
                        </span>
                      </div>
                    ))}
                  </div>

                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

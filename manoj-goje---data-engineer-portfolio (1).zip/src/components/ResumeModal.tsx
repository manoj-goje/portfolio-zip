import React, { useState } from 'react';
import { X, Printer, Download, FileDown, CheckCircle, ExternalLink } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useTheme } from '../context/ThemeContext';
import { downloadResumeSecure, printResumePDF } from '../utils/generateResumePDF';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose }) => {
  const { darkMode } = useTheme();
  const [downloaded, setDownloaded] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.4 },
      });
    } catch {}

    // First attempt: direct PDF-native auto-print
    try {
      printResumePDF();
    } catch {
      // Secondary fallback: print current window
      window.print();
    }
  };

  /**
   * Secure download handler linking directly to /resume.pdf in the public directory,
   * fetching the file as a Blob and enforcing an immediate browser download.
   */
  const handleSecureDownload = async () => {
    try {
      setIsDownloading(true);
      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.5 },
      });
      await downloadResumeSecure('Manoj_Goje_Resume.pdf');
      setDownloaded(true);
      setTimeout(() => setDownloaded(false), 3000);
    } catch (error) {
      console.error('Download error:', error);
      // Fallback: direct anchor download
      const link = document.createElement('a');
      link.href = '/resume.pdf';
      link.download = 'Manoj_Goje_Resume.pdf';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      
      {/* Modal Container */}
      <div className={`relative w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-4 max-h-[94vh] flex flex-col border ${
        darkMode
          ? 'bg-slate-900 border-slate-700'
          : 'bg-white border-[#d2e3fc]'
      }`}>
        
        {/* Modal Top Actions Header Bar */}
        <div className={`flex items-center justify-between px-5 py-3.5 border-b sticky top-0 z-20 ${
          darkMode
            ? 'border-slate-800 bg-slate-950/95 text-slate-100'
            : 'border-slate-200 bg-[#f8fafc] text-slate-800'
        }`}>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0078D4] animate-pulse"></span>
            <span className="font-bold text-sm">Resume Preview &bull; Manoj Goje</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="modal-download-resume-btn"
              onClick={handleSecureDownload}
              disabled={isDownloading}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#0078D4] hover:bg-[#106ebe] text-white font-bold text-xs transition-colors shadow-sm cursor-pointer active:scale-95 disabled:opacity-75"
              title="Download exact PDF resume file directly (/resume.pdf)"
            >
              {downloaded ? (
                <CheckCircle className="w-3.5 h-3.5 text-white" />
              ) : (
                <FileDown className="w-3.5 h-3.5" />
              )}
              <span>{downloaded ? 'Downloaded' : isDownloading ? 'Downloading...' : 'Download PDF'}</span>
            </button>

            <button
              type="button"
              id="modal-print-resume-btn"
              onClick={handlePrint}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold text-xs transition-colors border cursor-pointer active:scale-95 ${
                darkMode
                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
              }`}
              title="Print resume"
            >
              <Printer className="w-3.5 h-3.5 text-[#0078D4]" />
              <span>Print Resume</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                darkMode
                  ? 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200'
              }`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Resume Preview Body: Exact 1:1 format of the provided PDF */}
        <div className="p-6 sm:p-12 overflow-y-auto space-y-4 text-slate-950 font-serif bg-white text-[13px] leading-relaxed shadow-inner" id="resume-printable-area">
          
          {/* Header */}
          <div className="text-center space-y-1 pb-1">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-normal uppercase text-black font-serif">
              MANOJ GOJE
            </h1>
            <div className="text-xs sm:text-[13px] text-slate-800 flex flex-wrap items-center justify-center gap-2 pt-0.5 font-serif">
              <span>Pune, Maharashtra, India</span>
              <span>—</span>
              <span>8805861929</span>
              <span>—</span>
              <span>manojgoje02@gmail.com</span>
              <span>—</span>
              <a 
                href="https://linkedin.com/in/manoj-goje" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-[#0078D4] hover:underline"
              >
                linkedin.com/in/manoj-goje
              </a>
            </div>
          </div>

          {/* Professional Summary */}
          <div>
            <h2 className="text-sm font-bold tracking-normal border-b border-slate-800 pb-0.5 mb-1.5 font-serif text-black">
              Professional Summary
            </h2>
            <p className="text-xs text-slate-900 text-justify font-serif leading-relaxed">
              Data Operations Engineer – GIS Mapping with hands-on experience monitoring, validating, and maintaining large-scale geospatial and structured/semi-structured data pipelines. Skilled in incident diagnosis, root-cause analysis, and SLA-driven data quality resolution across enterprise mapping and analytics systems. Proficient in Azure cloud services, PySpark, and SQL for scalable data operations; experienced with data validation, feature engineering, and pipeline health monitoring on enterprise datasets. DP-203, AZ-104, and Databricks certified; adept at communicating operational outcomes to cross-functional stakeholders while adhering to data governance and compliance standards.
            </p>
          </div>

          {/* Technical Skills */}
          <div>
            <h2 className="text-sm font-bold tracking-normal border-b border-slate-800 pb-0.5 mb-1.5 font-serif text-black">
              Technical Skills
            </h2>
            <div className="space-y-1 text-xs text-slate-900 font-serif">
              <div className="flex gap-2">
                <span className="font-bold shrink-0 text-black">ML Frameworks &amp; Libraries:</span>
                <span>Python, Scikit-learn, PySpark, SQL, NLP, Predictive Modeling</span>
              </div>
              <div className="flex gap-2">
                <span className="font-bold shrink-0 text-black">Cloud Platforms:</span>
                <span>Microsoft Azure (ADF, Databricks, ADLS Gen2, Synapse Analytics, Azure SQL DB)</span>
              </div>
              <div className="flex gap-2">
                <span className="font-bold shrink-0 text-black">MLOps &amp; DevOps:</span>
                <span>Git, GitHub Actions, CI/CD, Docker, Jupyter, Delta Lake</span>
              </div>
              <div className="flex gap-2">
                <span className="font-bold shrink-0 text-black">Data Engineering:</span>
                <span>Feature Engineering, ETL/ELT, Batch &amp; Streaming Pipelines, Data Governance</span>
              </div>
              <div className="flex gap-2">
                <span className="font-bold shrink-0 text-black">Concepts:</span>
                <span>Machine Learning, Deep Learning Fundamentals, Incident Management, Root Cause Analysis</span>
              </div>
            </div>
          </div>

          {/* Professional Experience */}
          <div>
            <h2 className="text-sm font-bold tracking-normal border-b border-slate-800 pb-0.5 mb-1.5 font-serif text-black">
              Professional Experience
            </h2>
            <div className="space-y-1">
              <div className="flex flex-wrap items-baseline justify-between text-xs font-bold text-black font-serif">
                <span>Cognizant Technology Solutions</span>
                <span className="font-normal">Pune, Maharashtra</span>
              </div>
              <div className="flex flex-wrap items-baseline justify-between text-xs italic text-slate-800 font-serif">
                <span>Data Operations Engineer – GIS &amp; Mapping</span>
                <span className="font-normal not-italic text-slate-900">July 2025 – Present</span>
              </div>
              <ul className="list-disc list-outside pl-4 space-y-1 text-xs text-slate-900 font-serif pt-1">
                <li>Processed and validated large-scale clinical and geospatial datasets containing millions of records using Python and SQL pipelines, achieving 99%+ data accuracy in compliance with defined SLA standards across enterprise systems.</li>
                <li>Engineered end-to-end data cleansing, normalization, and feature validation pipelines across multiple enterprise databases, reducing data discrepancy incidents by 30% and improving downstream model-readiness of structured datasets.</li>
                <li>Collaborated with cross-functional analytics teams to translate business requirements into scalable data solutions, reducing average data quality resolution turnaround by 40% and improving pipeline reliability for reporting stakeholders.</li>
              </ul>
            </div>
          </div>

          {/* Key Projects */}
          <div>
            <h2 className="text-sm font-bold tracking-normal border-b border-slate-800 pb-0.5 mb-1.5 font-serif text-black">
              Key Projects
            </h2>
            <div className="space-y-3 font-serif">
              <div className="space-y-0.5">
                <div className="text-xs font-bold text-black">
                  ML-Ready Data Pipeline with Feature Engineering on Azure (Medallion Architecture)
                </div>
                <div className="text-xs italic text-slate-800">
                  Tech Stack: Azure Data Factory — ADLS Gen2 — Azure Databricks — PySpark — Delta Lake — Synapse Analytics — Python
                </div>
                <ul className="list-disc list-outside pl-4 space-y-1 text-xs text-slate-900 pt-0.5">
                  <li>Architected a multi-layer Medallion (Bronze/Silver/Gold) data pipeline ingesting structured CSV/JSON datasets via Azure Data Factory into ADLS Gen2, enabling feature-ready datasets for downstream ML model training at scale.</li>
                  <li>Implemented PySpark-based feature engineering and data transformation jobs in Azure Databricks, applying statistical normalization and schema evolution on Delta Lake tables to produce analytics-ready training datasets, reducing data prep time by 50%.</li>
                  <li>Built Gold-layer Synapse Analytics SQL views for BI and model evaluation reporting; deployed CI/CD automation via GitHub Actions, cutting pipeline release cycles from days to under 2 hours across dev and production environments.</li>
                </ul>
              </div>

              <div className="space-y-0.5">
                <div className="text-xs font-bold text-black">
                  Real-Time Predictive Event Streaming Pipeline — Azure Event Hub + Databricks
                </div>
                <div className="text-xs italic text-slate-800">
                  Tech Stack: Azure Event Hub — Azure Databricks — PySpark Structured Streaming — Delta Lake — Azure SQL DB
                </div>
                <ul className="list-disc list-outside pl-4 space-y-1 text-xs text-slate-900 pt-0.5">
                  <li>Designed and deployed a real-time ML-ready data streaming pipeline using Azure Event Hub and Databricks Structured Streaming, enabling exactly-once semantic ingestion of event data into Delta Lake for continuous model inference workflows.</li>
                  <li>Optimized checkpoint management and trigger intervals to achieve low-latency event processing, reducing end-to-end streaming latency by 35% and improving downstream dashboarding throughput for clinical analytics use cases.</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Certifications */}
          <div>
            <h2 className="text-sm font-bold tracking-normal border-b border-slate-800 pb-0.5 mb-1.5 font-serif text-black">
              Certifications
            </h2>
            <ul className="list-disc list-outside pl-4 space-y-0.5 text-xs text-slate-900 font-serif">
              <li>Microsoft Certified: Azure Administrator Associate AZ-104 — Microsoft</li>
              <li>Microsoft Certified: Azure Data Engineer Associate (DP-203) — Microsoft</li>
              <li>Databricks Certified Data Engineer Associate — Databricks</li>
            </ul>
          </div>

          {/* Education */}
          <div>
            <h2 className="text-sm font-bold tracking-normal border-b border-slate-800 pb-0.5 mb-1.5 font-serif text-black">
              Education
            </h2>
            <div className="text-xs text-slate-900 font-serif">
              <div className="flex justify-between items-baseline font-bold text-black">
                <span>Bachelor of Technology (B.Tech) — Computer Science and Engineering</span>
                <span className="font-normal">August 2020 – July 2024</span>
              </div>
              <div className="text-slate-800">
                Shreeyash College of Engineering and Technology, Aurangabad
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

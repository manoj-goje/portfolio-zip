import React from 'react';
import { LEADERSHIP_ACHIEVEMENTS } from '../data/portfolioData';
import { Trophy, Users, Code, Zap, CheckCircle2 } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export const Leadership: React.FC = () => {
  const { darkMode } = useTheme();

  const getIcon = (iconKey: string) => {
    switch (iconKey) {
      case 'trophy':
        return <Trophy className="w-5 h-5 text-amber-500" />;
      case 'users':
        return <Users className={`w-5 h-5 ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`} />;
      case 'code':
        return <Code className="w-5 h-5 text-emerald-500" />;
      default:
        return <Zap className="w-5 h-5 text-[#0078D4]" />;
    }
  };

  return (
    <section id="leadership" className={`py-16 relative border-t transition-colors ${
      darkMode ? 'bg-[#080f1e] border-[#1b3c73]' : 'bg-[#f4f8fc] border-[#d2e3fc]'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono mb-2 ${
            darkMode
              ? 'border-[#0078D4]/40 bg-[#0078D4]/10 text-cyan-300'
              : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
          }`}>
            <span>LEADERSHIP.INITIATIVES / HACKATHONS &amp; COMMUNITY</span>
          </div>
          <h2 className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Leadership, Hackathons &amp; Initiatives
          </h2>
          <p className={`text-sm sm:text-base mt-2 ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Demonstrated capabilities in competitive team leadership, large-scale technical event execution, and continuous algorithmic mastery.
          </p>
          <div className="w-16 h-1 bg-[#0078D4] mx-auto mt-3 rounded-full" />
        </div>

        {/* Quick Highlights Summary Badges */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 mb-8 max-w-4xl mx-auto">
          <div className={`p-3.5 rounded-xl border flex items-center gap-3 transition-colors ${
            darkMode ? 'bg-[#0d1b32] border-[#1b3c73]' : 'bg-white border-[#d2e3fc] shadow-sm'
          }`}>
            <div className={`w-9 h-9 rounded-lg border flex items-center justify-center flex-shrink-0 ${
              darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#fffbeb] border-amber-200'
            }`}>
              <Trophy className="w-4.5 h-4.5 text-amber-500" />
            </div>
            <div>
              <span className={`text-[10px] font-mono block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>TEAM LEADERSHIP</span>
              <span className={`text-xs sm:text-sm font-bold ${darkMode ? 'text-white' : 'text-slate-900'}`}>12-Player Squad Captain</span>
            </div>
          </div>

          <div className={`p-3.5 rounded-xl border flex items-center gap-3 transition-colors ${
            darkMode ? 'bg-[#0d1b32] border-[#1b3c73]' : 'bg-white border-[#d2e3fc] shadow-sm'
          }`}>
            <div className={`w-9 h-9 rounded-lg border flex items-center justify-center flex-shrink-0 ${
              darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#eff6ff] border-[#bfdbfe]'
            }`}>
              <Users className={`w-4.5 h-4.5 ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`} />
            </div>
            <div>
              <span className={`text-[10px] font-mono block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>EVENT COORDINATION</span>
              <span className={`text-xs sm:text-sm font-bold ${darkMode ? 'text-white' : 'text-slate-900'}`}>College Coding Organizer</span>
            </div>
          </div>

          <div className={`p-3.5 rounded-xl border flex items-center gap-3 transition-colors ${
            darkMode ? 'bg-[#0d1b32] border-[#1b3c73]' : 'bg-white border-[#d2e3fc] shadow-sm'
          }`}>
            <div className={`w-9 h-9 rounded-lg border flex items-center justify-center flex-shrink-0 ${
              darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#ecfdf5] border-emerald-200'
            }`}>
              <Code className="w-4.5 h-4.5 text-emerald-500" />
            </div>
            <div>
              <span className={`text-[10px] font-mono block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>COMPETITIVE SPRINT</span>
              <span className={`text-xs sm:text-sm font-bold ${darkMode ? 'text-white' : 'text-slate-900'}`}>50+ Contests &amp; Hackathons</span>
            </div>
          </div>
        </div>

        {/* 3 Detailed Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {LEADERSHIP_ACHIEVEMENTS.map((item) => (
            <div
              key={item.id}
              className={`flex flex-col justify-between p-5 rounded-xl border transition-all duration-300 shadow-xl ${
                darkMode
                  ? 'border-[#1b3c73] bg-[#0d1b32] hover:border-[#0078D4]'
                  : 'border-[#d2e3fc] bg-white hover:border-[#0078D4] hover:shadow-2xl'
              }`}
            >
              <div>
                {/* Card Header */}
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-10 h-10 rounded-lg border flex items-center justify-center ${
                    darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#f0f6ff] border-[#bfdbfe]'
                  }`}>
                    {getIcon(item.iconKey)}
                  </div>
                  <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border ${
                    darkMode
                      ? 'bg-[#001024] border-[#1b3c73] text-cyan-300'
                      : 'bg-[#eff6ff] border-[#bfdbfe] text-[#0078D4]'
                  }`}>
                    {item.tag}
                  </span>
                </div>

                <h3 className={`text-base font-bold mb-2 leading-snug ${
                  darkMode ? 'text-white' : 'text-slate-900'
                }`}>
                  {item.title}
                </h3>

                <p className={`text-xs leading-relaxed font-sans ${
                  darkMode ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  {item.description}
                </p>

                {/* Highlights List */}
                <div className={`mt-4 pt-3 border-t space-y-2 ${
                  darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
                }`}>
                  {item.highlights.map((highlight, hIdx) => (
                    <div key={hIdx} className={`flex items-start gap-2 text-xs ${
                      darkMode ? 'text-slate-300' : 'text-slate-700'
                    }`}>
                      <CheckCircle2 className={`w-3.5 h-3.5 flex-shrink-0 mt-0.5 ${
                        darkMode ? 'text-cyan-400' : 'text-[#0078D4]'
                      }`} />
                      <span>{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom Tag */}
              <div className={`mt-4 pt-3 border-t text-[10px] font-mono flex items-center justify-between ${
                darkMode ? 'border-[#1b3c73] text-slate-400' : 'border-slate-200 text-slate-500'
              }`}>
                <span>IMPACT:</span>
                <span className={`font-bold ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`}>{item.metric}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

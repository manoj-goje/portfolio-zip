import React, { useState } from 'react';
import {
  MapPin,
  Mail,
  Phone,
  ArrowRight,
  FileDown,
  CheckCircle2,
  Copy,
  Terminal,
  Activity,
  Server,
  Database,
  Layers,
  ShieldCheck,
  Cpu,
  Play,
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { TechIcon } from './TechIcon';
import { useTheme } from '../context/ThemeContext';
import { downloadResumePDF } from '../utils/generateResumePDF';

interface HeroProps {
  onOpenResume: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenResume }) => {
  const { darkMode } = useTheme();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const offset = 90;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = el.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-[85vh] pt-6 pb-16 md:pt-10 md:pb-20 flex items-center justify-center overflow-hidden"
    >
      {/* Background Decorative Tech Grids & Azure Blue Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-tr from-[#0078D4]/20 via-[#005a9e]/15 to-[#29b6f6]/10 blur-[130px] rounded-full" />
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#0078D4]/10 blur-[100px] rounded-full" />
        
        {/* Subtle Azure grid mesh */}
        <div
          className="absolute inset-0 opacity-[0.05]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #0078D4 1px, transparent 0)`,
            backgroundSize: '28px 28px',
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        
        {/* Azure Portal Top Resource Metadata Strip */}
        <div className={`mb-6 p-3 rounded-lg border flex flex-wrap items-center justify-between gap-3 text-xs font-mono shadow-sm transition-colors ${
          darkMode
            ? 'bg-[#0d1b32] border-[#1b3c73]'
            : 'bg-white border-[#d2e3fc] text-slate-700'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse ring-4 ring-emerald-500/20" />
            <span className={darkMode ? 'text-slate-300' : 'text-slate-500'}>Resource:</span>
            <span className={`font-bold ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`}>
              DataOperations/engineers/manoj-goje
            </span>
          </div>
          <div className={`flex items-center gap-4 text-[11px] ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            <span>Status: <strong className="text-emerald-500 font-semibold">Running (SLA 99.9%)</strong></span>
            <span className="hidden sm:inline">Region: <strong className={darkMode ? 'text-slate-200' : 'text-slate-800'}>Central India (Pune)</strong></span>
            <span className="hidden md:inline">Tier: <strong className={darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}>Enterprise Data Eng</strong></span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Column: Hero Content & Azure Portal Overview */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            {/* Azure Status Pill */}
            <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-md border text-xs font-mono backdrop-blur-sm shadow-sm transition-colors ${
              darkMode
                ? 'border-[#0078D4]/50 bg-[#0078D4]/15 text-cyan-200'
                : 'border-[#bfdbfe] bg-[#eff6ff] text-[#0078D4]'
            }`}>
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
              </span>
              <span>Azure Certified Data Engineer &bull; DP-203 &bull; Databricks</span>
            </div>

            {/* Main Name & Title */}
            <div className="space-y-2">
              <h1 className={`text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight ${
                darkMode ? 'text-white' : 'text-slate-900'
              }`}>
                Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-500 to-[#0078D4]">{PERSONAL_INFO.name}</span>
              </h1>
              
              <p className={`text-xl sm:text-2xl font-semibold flex flex-wrap items-center justify-center lg:justify-start gap-2 ${
                darkMode ? 'text-slate-200' : 'text-slate-800'
              }`}>
                <span>{PERSONAL_INFO.title}</span>
              </p>

              <p className={`text-base sm:text-lg font-mono ${
                darkMode ? 'text-cyan-200/90' : 'text-[#0078D4]'
              }`}>
                &gt; {PERSONAL_INFO.tagline}
              </p>
            </div>

            {/* Azure Resource Tags */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 text-xs font-mono">
              {['ADF v2', 'Azure Databricks', 'PySpark & Delta Lake', 'ADLS Gen2', 'Cognizant Tech Solutions'].map((tag) => (
                <span
                  key={tag}
                  className={`px-2.5 py-1 rounded border transition-colors ${
                    darkMode
                      ? 'bg-[#001833] border-[#1b3c73] text-slate-300'
                      : 'bg-[#f0f6ff] border-[#bfdbfe] text-slate-700'
                  }`}
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Action Buttons (CTAs Styled in Azure Portal Fluent Buttons) */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2">
              <button
                type="button"
                onClick={() => scrollToSection('projects')}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-md bg-[#0078D4] hover:bg-[#106ebe] text-white font-semibold text-sm tracking-wide shadow-md transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
              >
                <span>View Lakehouse Projects</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => downloadResumePDF()}
                className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-md border font-semibold text-sm transition-all cursor-pointer shadow-sm ${
                  darkMode
                    ? 'bg-[#0d1b32] hover:bg-[#163566] border-[#1b3c73] text-slate-100 hover:border-[#0078D4]'
                    : 'bg-white hover:bg-slate-50 border-slate-300 text-slate-800 hover:border-[#0078D4]'
                }`}
              >
                <FileDown className="w-4 h-4 text-[#0078D4]" />
                <span>Download Resume (PDF)</span>
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('contact')}
                className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-md border font-medium text-sm transition-all cursor-pointer ${
                  darkMode
                    ? 'bg-[#001833] hover:bg-[#002b5c] border-cyan-500/40 text-cyan-300'
                    : 'bg-[#eff6ff] hover:bg-[#e0edff] border-[#bfdbfe] text-[#0078D4]'
                }`}
              >
                <Mail className="w-4 h-4" />
                <span>Contact / Hire</span>
              </button>
            </div>

            {/* Social Links & Quick Contact Pills */}
            <div className={`pt-3 border-t flex flex-wrap items-center justify-center lg:justify-start gap-3 ${
              darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
            }`}>
              {/* LinkedIn */}
              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-md border text-xs transition-colors ${
                  darkMode
                    ? 'bg-[#0d1b32] hover:bg-[#163566] border-[#1b3c73] text-slate-300 hover:text-cyan-300'
                    : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700 hover:text-[#0078D4]'
                }`}
              >
                <TechIcon name="linkedin" className="w-3.5 h-3.5" />
                <span>{PERSONAL_INFO.linkedinHandle}</span>
              </a>

              {/* Email with copy button */}
              <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-xs ${
                darkMode
                  ? 'bg-[#0d1b32] border-[#1b3c73] text-slate-300'
                  : 'bg-white border-slate-200 text-slate-700'
              }`}>
                <Mail className="w-3.5 h-3.5 text-[#0078D4]" />
                <a
                  href={`mailto:${PERSONAL_INFO.email}`}
                  className="hover:text-[#0078D4] transition-colors font-mono"
                >
                  {PERSONAL_INFO.email}
                </a>
                <button
                  type="button"
                  onClick={() => handleCopy(PERSONAL_INFO.email, 'email')}
                  className="p-1 text-slate-400 hover:text-[#0078D4] transition-colors cursor-pointer"
                  title="Copy email to clipboard"
                >
                  {copiedKey === 'email' ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>

              {/* Phone */}
              <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-xs ${
                darkMode
                  ? 'bg-[#0d1b32] border-[#1b3c73] text-slate-300'
                  : 'bg-white border-slate-200 text-slate-700'
              }`}>
                <Phone className="w-3.5 h-3.5 text-emerald-500" />
                <a
                  href={`tel:${PERSONAL_INFO.phone}`}
                  className="hover:text-[#0078D4] transition-colors font-mono"
                >
                  {PERSONAL_INFO.phoneFormatted}
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Live Azure Monitor & Data Pipeline Telemetry Card */}
          <div className="lg:col-span-5 flex justify-center">
            <div className={`w-full max-w-md rounded-xl border shadow-2xl p-4 sm:p-5 backdrop-blur-xl relative overflow-hidden transition-colors ${
              darkMode
                ? 'bg-[#0d1b32] border-[#1b3c73]'
                : 'bg-white border-[#d2e3fc]'
            }`}>
              
              {/* Azure Monitor top window bar */}
              <div className={`flex items-center justify-between pb-3 mb-3 border-b ${
                darkMode ? 'border-[#1b3c73]' : 'border-slate-200'
              }`}>
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className={`text-[11px] font-mono ml-1 font-semibold flex items-center gap-1.5 ${
                    darkMode ? 'text-slate-300' : 'text-slate-700'
                  }`}>
                    <Activity className="w-3.5 h-3.5 text-[#0078D4]" />
                    Azure Monitor &bull; DataOps
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] font-mono text-emerald-500 bg-emerald-950/20 px-2 py-0.5 rounded border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>SLA 99.9% HEALTHY</span>
                </div>
              </div>

              {/* Telemetry Metric Feed */}
              <div className="space-y-3 font-mono text-xs">
                
                <div className={`rounded-lg p-3 border space-y-1.5 ${
                  darkMode
                    ? 'bg-[#001024] border-[#1b3c73]'
                    : 'bg-[#f0f6ff] border-[#bfdbfe]'
                }`}>
                  <div className={`text-[11px] flex items-center justify-between ${
                    darkMode ? 'text-slate-400' : 'text-slate-500'
                  }`}>
                    <span className={darkMode ? 'text-cyan-400' : 'text-[#0078D4] font-bold'}>azure@dataops:~$</span>
                    <span className="text-[10px]">Databricks 13.3 LTS</span>
                  </div>
                  <div className="text-emerald-500 text-[11px] flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Medallion Pipeline: Bronze &rarr; Silver &rarr; Gold</span>
                  </div>
                  <div className={`text-[10px] pl-3 border-l space-y-0.5 ${
                    darkMode ? 'text-slate-300 border-[#1b3c73]' : 'text-slate-600 border-slate-300'
                  }`}>
                    <div>&bull; ADLS Gen2 Ingestion: Schema Enforcement</div>
                    <div>&bull; PySpark Transforms: 40% Triage Acceleration</div>
                    <div>&bull; Delta Lake ACID: 30% Discrepancy Reduction</div>
                  </div>
                </div>

                {/* Live Azure Metrics Grid */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div className={`p-2.5 rounded-lg border ${
                    darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#f8fafc] border-slate-200'
                  }`}>
                    <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>SLA ACCURACY</span>
                    <span className={`text-lg font-bold font-mono ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`}>99%+</span>
                    <span className="text-[9px] text-emerald-500 block mt-0.5">Cognizant Tech Baseline</span>
                  </div>

                  <div className={`p-2.5 rounded-lg border ${
                    darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#f8fafc] border-slate-200'
                  }`}>
                    <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>DATA DISCREPANCIES</span>
                    <span className="text-lg font-bold text-teal-500 font-mono">-30%</span>
                    <span className={`text-[9px] block mt-0.5 ${darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}`}>Automated Validation</span>
                  </div>

                  <div className={`p-2.5 rounded-lg border ${
                    darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#f8fafc] border-slate-200'
                  }`}>
                    <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>INCIDENT TRIAGE</span>
                    <span className="text-lg font-bold text-amber-500 font-mono">40% Faster</span>
                    <span className={`text-[9px] block mt-0.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Root Cause Diagnosis</span>
                  </div>

                  <div className={`p-2.5 rounded-lg border ${
                    darkMode ? 'bg-[#001024] border-[#1b3c73]' : 'bg-[#f8fafc] border-slate-200'
                  }`}>
                    <span className={`text-[10px] block ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>AZURE / AI CERTS</span>
                    <span className={`text-lg font-bold font-mono ${darkMode ? 'text-[#29b6f6]' : 'text-[#0078D4]'}`}>4x Active</span>
                    <span className={`text-[9px] block mt-0.5 ${darkMode ? 'text-cyan-400' : 'text-[#0078D4]'}`}>DP-203, Databricks, AI</span>
                  </div>
                </div>

                {/* Footer status pill inside card */}
                <div className={`flex items-center justify-between text-[10px] pt-1 border-t ${
                  darkMode ? 'text-slate-400 border-[#1b3c73]/60' : 'text-slate-500 border-slate-200'
                }`}>
                  <span className="flex items-center gap-1">
                    <Server className="w-3 h-3 text-[#0078D4]" />
                    <span>GIS &amp; Production Telemetry</span>
                  </span>
                  <span className={`font-semibold font-mono ${darkMode ? 'text-cyan-300' : 'text-[#0078D4]'}`}>
                    sub-dataops-001
                  </span>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

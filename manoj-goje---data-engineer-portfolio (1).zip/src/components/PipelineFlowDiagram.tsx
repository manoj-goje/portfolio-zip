import React, { useState } from 'react';
import { PipelineNodeData, PipelineEdgeData } from '../types';
import { TechIcon } from './TechIcon';
import { ChevronRight, ArrowDown, Activity, Info, X, Zap } from 'lucide-react';

interface PipelineFlowDiagramProps {
  nodes: PipelineNodeData[];
  edges: PipelineEdgeData[];
  title?: string;
  isDark?: boolean;
}

export const PipelineFlowDiagram: React.FC<PipelineFlowDiagramProps> = ({
  nodes,
  edges,
  isDark = true,
}) => {
  const [selectedNode, setSelectedNode] = useState<PipelineNodeData | null>(null);
  const [isLive, setIsLive] = useState(true);

  return (
    <div className={`w-full my-4 rounded-xl border p-4 sm:p-5 backdrop-blur-md transition-all shadow-inner ${
      isDark
        ? 'border-slate-800 bg-slate-950/70 text-slate-200'
        : 'border-[#d2e3fc] bg-[#f0f6ff]/80 text-slate-800'
    }`}>
      {/* Header bar of Diagram */}
      <div className={`flex flex-wrap items-center justify-between gap-2 pb-3 mb-4 border-b text-xs ${
        isDark ? 'border-slate-800' : 'border-[#d2e3fc]'
      }`}>
        <div className={`flex items-center gap-2 font-mono ${isDark ? 'text-cyan-400' : 'text-[#0078D4]'}`}>
          <span className="relative flex h-2 w-2">
            {isLive && (
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#0078D4] opacity-75"></span>
            )}
            <span className={`relative inline-flex rounded-full h-2 w-2 ${isLive ? 'bg-[#0078D4]' : 'bg-slate-400'}`}></span>
          </span>
          <span className="font-semibold uppercase tracking-wider text-[11px]">
            Dataflow Architecture Diagram
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsLive(!isLive)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-mono transition-colors ${
              isLive
                ? isDark
                  ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30'
                  : 'bg-[#0078D4]/10 text-[#0078D4] border border-[#0078D4]/30'
                : isDark
                  ? 'bg-slate-800 text-slate-400 border border-slate-700'
                  : 'bg-slate-200 text-slate-600 border border-slate-300'
            }`}
            title="Toggle live animated data flow"
          >
            <Zap className={`w-3 h-3 ${isLive ? (isDark ? 'text-cyan-400 fill-cyan-400' : 'text-[#0078D4] fill-[#0078D4]') : 'text-slate-400'}`} />
            {isLive ? 'Live Flow ON' : 'Flow Paused'}
          </button>
          
          <span className={`text-[11px] hidden sm:inline ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Click node for specs
          </span>
        </div>
      </div>

      {/* Desktop Horizontal Layout (md+) */}
      <div className="hidden md:block overflow-x-auto pb-2 scrollbar-thin">
        <div className="flex items-center min-w-max py-2 px-1">
          {nodes.map((node, index) => {
            const isEdgePresent = index < edges.length;
            const edge = isEdgePresent ? edges[index] : null;
            const isSelected = selectedNode?.id === node.id;

            return (
              <React.Fragment key={node.id}>
                {/* Node Box */}
                <button
                  type="button"
                  onClick={() => setSelectedNode(isSelected ? null : node)}
                  className={`group relative flex flex-col items-center p-3 rounded-lg border text-left transition-all duration-200 cursor-pointer min-w-[125px] max-w-[155px] ${
                    isSelected
                      ? isDark
                        ? 'bg-cyan-950/60 border-cyan-400 shadow-md shadow-cyan-500/20 scale-[1.03] ring-1 ring-cyan-400'
                        : 'bg-[#e0edff] border-[#0078D4] shadow-md scale-[1.03] ring-1 ring-[#0078D4]'
                      : isDark
                        ? 'bg-slate-900/90 border-slate-700 hover:border-cyan-500/60 hover:bg-slate-800'
                        : 'bg-white border-slate-200 hover:border-[#0078D4] hover:bg-slate-50 shadow-sm'
                  }`}
                >
                  {/* Layer indicator pill */}
                  {node.layer && (
                    <span
                      className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded-full mb-1.5 font-medium ${
                        node.badgeColor || (isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-100 text-slate-700')
                      }`}
                    >
                      {node.layer}
                    </span>
                  )}

                  {/* Icon */}
                  <div className={`w-8 h-8 flex items-center justify-center rounded-lg p-1 mb-2 group-hover:scale-110 transition-transform ${
                    isDark ? 'bg-slate-950/50' : 'bg-[#f0f6ff]'
                  }`}>
                    <TechIcon name={node.iconKey || node.title} className="w-6 h-6" />
                  </div>

                  {/* Title & Subtitle */}
                  <span className={`text-[12px] font-semibold text-center leading-tight line-clamp-2 ${
                    isDark ? 'text-slate-200' : 'text-slate-900'
                  }`}>
                    {node.title}
                  </span>
                  {node.subtitle && (
                    <span className={`text-[10px] font-mono text-center mt-1 ${
                      isDark ? 'text-slate-400' : 'text-slate-500'
                    }`}>
                      {node.subtitle}
                    </span>
                  )}

                  {/* Info dot indicator */}
                  <span className="absolute top-1.5 right-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Info className={`w-3 h-3 ${isDark ? 'text-cyan-400' : 'text-[#0078D4]'}`} />
                  </span>
                </button>

                {/* Connector Arrow & Edge Label */}
                {isEdgePresent && edge && (
                  <div className="flex flex-col items-center justify-center px-1.5 min-w-[75px] max-w-[100px] text-center relative">
                    <span className={`text-[10px] font-mono mb-1 leading-none truncate max-w-[90px] px-1 rounded border ${
                      isDark
                        ? 'text-cyan-300 bg-slate-900/90 border-slate-800'
                        : 'text-[#0078D4] bg-white border-slate-200 shadow-xs'
                    }`}>
                      {edge.label}
                    </span>

                    {/* Animated Line with SVG */}
                    <div className="relative w-full flex items-center justify-center my-1">
                      <svg className="w-full h-4" viewBox="0 0 100 16" preserveAspectRatio="none">
                        <line
                          x1="0"
                          y1="8"
                          x2="85"
                          y2="8"
                          stroke={isDark ? '#38bdf8' : '#0078D4'}
                          strokeWidth="2"
                          strokeDasharray={isLive ? '4 3' : undefined}
                          className={isLive ? 'animate-pulse-flow' : ''}
                        />
                        <polygon
                          points="85,4 98,8 85,12"
                          fill={isDark ? '#38bdf8' : '#0078D4'}
                        />
                      </svg>

                      {/* Moving pulse dot */}
                      {isLive && (
                        <div className={`absolute top-1/2 -translate-y-1/2 w-2 h-2 rounded-full shadow-sm animate-packet-h ${
                          isDark ? 'bg-cyan-300 shadow-cyan-300' : 'bg-[#0078D4] shadow-[#0078D4]'
                        }`} />
                      )}
                    </div>
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Mobile Vertical Layout (<md) */}
      <div className="block md:hidden space-y-3 py-1">
        {nodes.map((node, index) => {
          const isEdgePresent = index < edges.length;
          const edge = isEdgePresent ? edges[index] : null;
          const isSelected = selectedNode?.id === node.id;

          return (
            <div key={node.id} className="flex flex-col items-center">
              {/* Vertical Node Card */}
              <button
                type="button"
                onClick={() => setSelectedNode(isSelected ? null : node)}
                className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all ${
                  isSelected
                    ? isDark
                      ? 'bg-cyan-950/70 border-cyan-400 shadow-md shadow-cyan-500/20 ring-1 ring-cyan-400'
                      : 'bg-[#e0edff] border-[#0078D4] shadow-md ring-1 ring-[#0078D4]'
                    : isDark
                      ? 'bg-slate-900/90 border-slate-700'
                      : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 flex items-center justify-center rounded-lg p-1.5 flex-shrink-0 ${
                    isDark ? 'bg-slate-950/60' : 'bg-[#f0f6ff]'
                  }`}>
                    <TechIcon name={node.iconKey || node.title} className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-semibold ${isDark ? 'text-slate-100' : 'text-slate-900'}`}>
                        {node.title}
                      </span>
                      {node.layer && (
                        <span
                          className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded-full ${
                            node.badgeColor || (isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-100 text-slate-700')
                          }`}
                        >
                          {node.layer}
                        </span>
                      )}
                    </div>
                    {node.subtitle && (
                      <span className={`text-xs font-mono block ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                        {node.subtitle}
                      </span>
                    )}
                  </div>
                </div>

                <Info className={`w-4 h-4 flex-shrink-0 ${isDark ? 'text-cyan-400' : 'text-[#0078D4]'}`} />
              </button>

              {/* Vertical Animated Arrow */}
              {isEdgePresent && edge && (
                <div className="flex flex-col items-center my-2 relative py-1">
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border mb-1 ${
                    isDark ? 'text-cyan-300 bg-slate-900 border-slate-800' : 'text-[#0078D4] bg-white border-slate-200'
                  }`}>
                    {edge.label}
                  </span>
                  <div className="relative h-6 w-4 flex flex-col items-center justify-center">
                    <div className={`w-0.5 h-full ${isDark ? 'bg-cyan-400' : 'bg-[#0078D4]'} ${isLive ? 'border-l-2 border-dashed' : ''}`} />
                    <ArrowDown className={`w-4 h-4 -mt-1 ${isDark ? 'text-cyan-400' : 'text-[#0078D4]'}`} />
                    {isLive && (
                      <div className={`absolute left-1/2 -translate-x-1/2 w-2 h-2 rounded-full shadow-sm animate-packet-v ${
                        isDark ? 'bg-cyan-300 shadow-cyan-300' : 'bg-[#0078D4] shadow-[#0078D4]'
                      }`} />
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Selected Node Details Tray / Modal */}
      {selectedNode && (
        <div className={`mt-3 p-3.5 rounded-lg border text-xs animate-in fade-in slide-in-from-top-1 duration-200 ${
          isDark
            ? 'border-cyan-500/40 bg-slate-900/95 text-slate-200'
            : 'border-[#0078D4]/40 bg-white text-slate-800 shadow-lg'
        }`}>
          <div className={`flex items-center justify-between pb-2 mb-2 border-b ${
            isDark ? 'border-slate-800' : 'border-slate-200'
          }`}>
            <div className="flex items-center gap-2">
              <TechIcon name={selectedNode.iconKey || selectedNode.title} className="w-4 h-4" />
              <span className={`font-bold ${isDark ? 'text-slate-100' : 'text-slate-900'}`}>{selectedNode.title}</span>
              {selectedNode.subtitle && (
                <span className={`font-mono text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>({selectedNode.subtitle})</span>
              )}
            </div>
            <button
              type="button"
              onClick={() => setSelectedNode(null)}
              className={`p-1 ${isDark ? 'text-slate-400 hover:text-slate-200' : 'text-slate-500 hover:text-slate-800'}`}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
            {selectedNode.details?.engine && (
              <div>
                <span className={`font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Compute Engine: </span>
                <span className={`font-medium ${isDark ? 'text-cyan-300' : 'text-[#0078D4]'}`}>{selectedNode.details.engine}</span>
              </div>
            )}
            {selectedNode.details?.format && (
              <div>
                <span className={`font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Data Format: </span>
                <span className="text-emerald-500 font-medium">{selectedNode.details.format}</span>
              </div>
            )}
            {selectedNode.details?.sla && (
              <div>
                <span className={`font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>SLA / Ingestion: </span>
                <span className="text-amber-500 font-medium">{selectedNode.details.sla}</span>
              </div>
            )}
            {selectedNode.details?.partition && (
              <div>
                <span className={`font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Partitioning: </span>
                <span className="text-purple-500 font-medium">{selectedNode.details.partition}</span>
              </div>
            )}
            {selectedNode.details?.purpose && (
              <div className="sm:col-span-2">
                <span className={`font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Operational Purpose: </span>
                <span className={isDark ? 'text-slate-300' : 'text-slate-700'}>{selectedNode.details.purpose}</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

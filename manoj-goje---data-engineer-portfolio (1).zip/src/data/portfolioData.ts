import {
  SkillItem,
  ProjectData,
  ExperienceData,
  CertificationData,
  EducationData,
  LeadershipItem,
} from '../types';

export const PERSONAL_INFO = {
  name: 'Manoj Goje',
  title: 'Data Operations Engineer – GIS & Mapping',
  tagline: 'Building scalable, ML-ready data pipelines on Azure',
  location: 'Pune, Maharashtra, India',
  email: 'manojgoje02@gmail.com',
  phone: '8805861929',
  phoneFormatted: '+91 8805861929',
  linkedin: 'https://www.linkedin.com/in/manoj-g-',
  linkedinHandle: 'www.linkedin.com/in/manoj-g-',
  github: 'https://github.com',
  availability: 'Actively Interviewing for Data Engineering & Operations Roles',
  summary:
    'Data Operations Engineer with hands-on experience monitoring, validating, and maintaining large-scale geospatial and structured/semi-structured data pipelines. Skilled in incident diagnosis, root-cause analysis, and SLA-driven data quality resolution across enterprise mapping and analytics systems. Proficient in Azure cloud services, PySpark, and SQL for scalable data operations. DP-203, AZ-104, Databricks, and Oracle Agentic AI certified.',
  stats: [
    { label: 'Pipeline SLA Accuracy', value: '99%+', highlight: 'SLA Guaranteed' },
    { label: 'Data Discrepancy Reduction', value: '30%', highlight: 'Root-Cause Fixes' },
    { label: 'SLA Resolution Turnaround', value: '40% Faster', highlight: 'Automated Triaging' },
    { label: 'Cloud & Lakehouse Certs', value: '3x', highlight: 'DP-203, AZ-104, Databricks' },
  ],
};

export const TECHNICAL_SKILLS: SkillItem[] = [
  // Cloud Platforms
  {
    name: 'Azure Data Factory',
    category: 'cloud',
    iconKey: 'datafactory',
    description: 'Orchestrated ETL/ELT pipelines, tumbling window triggers, linked services, and parameterized ADF activities.',
    experienceLevel: 'Advanced',
    brandColor: '#0078D4',
  },
  {
    name: 'Azure Databricks',
    category: 'cloud',
    iconKey: 'databricks',
    description: 'Managed Apache Spark compute clusters, Delta Lake tables, PySpark notebooks, and Lakehouse architectures.',
    experienceLevel: 'Certified Associate',
    brandColor: '#FF3621',
  },
  {
    name: 'ADLS Gen2',
    category: 'cloud',
    iconKey: 'adls',
    description: 'Hierarchical namespace storage, Medallion Bronze/Silver/Gold tiers, and role-based ACL access control.',
    experienceLevel: 'Advanced',
    brandColor: '#0089D6',
  },
  {
    name: 'Synapse Analytics',
    category: 'cloud',
    iconKey: 'synapse',
    description: 'Serverless and dedicated SQL pools, Gold-layer analytical querying, views, and BI integration.',
    experienceLevel: 'Proficient',
    brandColor: '#0078D4',
  },
  {
    name: 'Azure SQL DB',
    category: 'cloud',
    iconKey: 'azuresql',
    description: 'High-throughput relational data staging, indexing, transactional integrity, and operational reporting.',
    experienceLevel: 'Proficient',
    brandColor: '#0078D4',
  },

  // Languages & Frameworks
  {
    name: 'Python',
    category: 'languages',
    iconKey: 'python',
    description: 'Core programming for pipeline automation, data validation algorithms, logging, and PySpark transformations.',
    experienceLevel: 'Advanced',
    brandColor: '#3776AB',
  },
  {
    name: 'SQL',
    category: 'languages',
    iconKey: 'postgresql',
    description: 'Complex window functions, schema validation queries, CTEs, indexing, and high-performance data verification.',
    experienceLevel: 'Expert',
    brandColor: '#336791',
  },
  {
    name: 'PySpark',
    category: 'languages',
    iconKey: 'pyspark',
    description: 'Distributed DataFrame transformations, schema evolution, partition pruning, and structured streaming.',
    experienceLevel: 'Advanced',
    brandColor: '#E25A1C',
  },
  {
    name: 'Scikit-learn',
    category: 'languages',
    iconKey: 'scikitlearn',
    description: 'Feature engineering pipelines, data scaling, encoding, and ML-ready feature store preparations.',
    experienceLevel: 'Proficient',
    brandColor: '#F7931E',
  },

  // MLOps & DevOps
  {
    name: 'Git',
    category: 'mlops',
    iconKey: 'git',
    description: 'Version control, branch protection strategies, code reviews, and GitOps pipeline versioning.',
    experienceLevel: 'Advanced',
    brandColor: '#F05032',
  },
  {
    name: 'GitHub Actions',
    category: 'mlops',
    iconKey: 'githubactions',
    description: 'CI/CD workflow automation, automated unit testing, deployment triggers, and linting checks.',
    experienceLevel: 'Proficient',
    brandColor: '#2088FF',
  },
  {
    name: 'CI/CD',
    category: 'mlops',
    iconKey: 'cicd',
    description: 'Automated artifact packaging, environment promotion (Dev/Stage/Prod), and zero-downtime releases.',
    experienceLevel: 'Proficient',
    brandColor: '#00BCF2',
  },
  {
    name: 'Docker',
    category: 'mlops',
    iconKey: 'docker',
    description: 'Containerized data processing microservices, reproducible environment configurations, and image builds.',
    experienceLevel: 'Intermediate',
    brandColor: '#2496ED',
  },
  {
    name: 'Jupyter',
    category: 'mlops',
    iconKey: 'jupyter',
    description: 'Exploratory data analysis, geospatial visualization notebooks, algorithm prototyping, and validation testing.',
    experienceLevel: 'Advanced',
    brandColor: '#F37626',
  },
  {
    name: 'Delta Lake',
    category: 'mlops',
    iconKey: 'deltalake',
    description: 'ACID transactions on object storage, time travel, schema enforcement, and parquet-optimized storage.',
    experienceLevel: 'Advanced',
    brandColor: '#00A9E0',
  },

  // Data Engineering
  {
    name: 'ETL / ELT',
    category: 'data_eng',
    iconKey: 'etl',
    description: 'Multi-stage data extraction, high-volume transformation, and ingestion workflows for analytics & ML.',
    experienceLevel: 'Advanced',
    brandColor: '#06B6D4',
  },
  {
    name: 'Batch & Streaming',
    category: 'data_eng',
    iconKey: 'eventhub',
    description: 'Event-driven streaming with checkpointed micro-batches and scheduled batch ingestion architectures.',
    experienceLevel: 'Advanced',
    brandColor: '#804998',
  },
  {
    name: 'Data Governance',
    category: 'data_eng',
    iconKey: 'governance',
    description: 'Data lineage, quality profiling, SLA monitoring, anomaly detection, and schema compliance tracking.',
    experienceLevel: 'Advanced',
    brandColor: '#10B981',
  },
];

export const EXPERIENCE_LIST: ExperienceData[] = [
  {
    company: 'Cognizant Technology Solutions',
    role: 'Data Operations Engineer – GIS & Mapping',
    period: 'July 2025 – Present',
    location: 'Pune, Maharashtra',
    summary:
      'Responsible for operating, monitoring, and debugging enterprise-grade geospatial and structured data pipelines powering mission-critical mapping platforms and analytics downstream systems.',
    bullets: [
      'Processed and validated large-scale clinical and geospatial datasets containing millions of records using Python and SQL pipelines, achieving 99%+ data accuracy against SLA standards.',
      'Engineered end-to-end data cleansing, normalization, and feature validation pipelines across multiple enterprise databases, reducing data discrepancy incidents by 30%.',
      'Collaborated with cross-functional analytics teams to translate business requirements into scalable data solutions, reducing average data quality resolution turnaround by 40%.',
    ],
    skills: [
      'GIS & Mapping Data',
      'Python',
      'SQL',
      'PySpark',
      'Azure Data Ops',
      'Incident Diagnosis',
      'SLA Governance',
      'Root-Cause Analysis',
    ],
    metrics: [
      { label: 'Data Accuracy', value: '99%+' },
      { label: 'Incident Reduction', value: '-30%' },
      { label: 'Resolution Speed', value: '+40%' },
    ],
  },
];

export const PROJECTS_LIST: ProjectData[] = [
  {
    id: 'medallion-pipeline',
    title: 'ML-Ready Data Pipeline with Feature Engineering on Azure',
    subtitle: 'Medallion Architecture (Bronze → Silver → Gold Lakehouse)',
    tagline: 'High-throughput enterprise lakehouse pipeline processing multi-format raw data into curated, ML-ready feature stores.',
    techStack: [
      { name: 'Azure Data Factory', iconKey: 'datafactory' },
      { name: 'ADLS Gen2', iconKey: 'adls' },
      { name: 'Azure Databricks', iconKey: 'databricks' },
      { name: 'PySpark', iconKey: 'pyspark' },
      { name: 'Delta Lake', iconKey: 'deltalake' },
      { name: 'Synapse Analytics', iconKey: 'synapse' },
      { name: 'Python', iconKey: 'python' },
    ],
    bullets: [
      'Architected a multi-layer Medallion (Bronze/Silver/Gold) pipeline ingesting structured CSV/JSON datasets via ADF into ADLS Gen2 for downstream ML training.',
      'Implemented PySpark feature engineering and schema evolution on Delta Lake tables, reducing data prep time by 50%.',
      'Built Gold-layer Synapse SQL views for BI reporting; deployed CI/CD via GitHub Actions, cutting release cycles from days to under 2 hours.',
    ],
    metrics: [
      { label: 'Data Prep Time', value: '-50%' },
      { label: 'Release Cycle', value: '< 2 Hours' },
      { label: 'Data Tiers', value: '3 (Bronze/Silver/Gold)' },
    ],
    flowNodes: [
      {
        id: 'src-1',
        title: 'CSV/JSON Source',
        subtitle: 'Raw Feeds',
        iconKey: 'csv',
        layer: 'source',
        badgeColor: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10',
        details: {
          format: 'CSV / JSON raw feeds',
          sla: 'Daily / Hourly batch',
          purpose: 'Landing ingestion point for upstream application logs & records',
        },
      },
      {
        id: 'adf-1',
        title: 'ADF Ingestion',
        subtitle: 'Orchestration',
        iconKey: 'datafactory',
        layer: 'ingest',
        badgeColor: 'border-blue-500/40 text-blue-400 bg-blue-500/10',
        details: {
          engine: 'Azure Data Factory Pipelines',
          sla: 'Automated trigger / monitoring',
          purpose: 'Copy activity with error logging and automated retry mechanisms',
        },
      },
      {
        id: 'adls-bronze',
        title: 'ADLS Gen2 Bronze',
        subtitle: 'Raw Lakehouse',
        iconKey: 'adls',
        layer: 'bronze',
        badgeColor: 'border-amber-600/40 text-amber-400 bg-amber-600/10',
        details: {
          format: 'Parquet / Delta raw snapshot',
          partition: 'Year / Month / Ingestion_Date',
          purpose: 'Immutable single source of raw truth preservation',
        },
      },
      {
        id: 'spark-silver',
        title: 'PySpark in Databricks',
        subtitle: 'Cleansing & Dedup',
        iconKey: 'databricks',
        layer: 'silver',
        badgeColor: 'border-red-500/40 text-red-400 bg-red-500/10',
        details: {
          engine: 'Apache Spark / Databricks Compute',
          purpose: 'Data type casting, null filling, schema validation, deduplication',
        },
      },
      {
        id: 'delta-silver',
        title: 'Delta Lake Silver',
        subtitle: 'Cleaned Data',
        iconKey: 'deltalake',
        layer: 'silver',
        badgeColor: 'border-cyan-500/40 text-cyan-400 bg-cyan-500/10',
        details: {
          format: 'Delta Parquet with ACID logs',
          sla: 'Schema enforcement enabled',
          purpose: 'Standardized enterprise-wide operational dataset',
        },
      },
      {
        id: 'delta-gold',
        title: 'Delta Lake Gold',
        subtitle: 'ML Feature Store',
        iconKey: 'deltalake',
        layer: 'gold',
        badgeColor: 'border-yellow-400/40 text-yellow-400 bg-yellow-400/10',
        details: {
          format: 'Optimized Aggregated Delta tables',
          purpose: 'Curated feature engineering for ML training & analytics',
        },
      },
      {
        id: 'synapse-bi',
        title: 'Synapse / BI',
        subtitle: 'SQL Views & Serving',
        iconKey: 'synapse',
        layer: 'serving',
        badgeColor: 'border-indigo-400/40 text-indigo-400 bg-indigo-400/10',
        details: {
          engine: 'Synapse Serverless SQL Pools',
          purpose: 'High-speed SQL views for executive dashboards & ML endpoints',
        },
      },
    ],
    flowEdges: [
      { label: 'ADF ingest' },
      { label: 'Landing write' },
      { label: 'PySpark transform' },
      { label: 'ACID commit' },
      { label: 'Feature engineering' },
      { label: 'SQL views' },
    ],
  },
  {
    id: 'streaming-pipeline',
    title: 'Real-Time Predictive Event Streaming Pipeline',
    subtitle: 'Low-Latency Event Hub & Structured Streaming Architecture',
    tagline: 'End-to-end streaming data pipeline capturing live event telemetry with exactly-once semantic delivery.',
    techStack: [
      { name: 'Azure Event Hub', iconKey: 'eventhub' },
      { name: 'Azure Databricks', iconKey: 'databricks' },
      { name: 'PySpark', iconKey: 'pyspark' },
      { name: 'Delta Lake', iconKey: 'deltalake' },
      { name: 'Azure SQL DB', iconKey: 'azuresql' },
    ],
    bullets: [
      'Designed a real-time ML-ready streaming pipeline using Event Hub and Databricks Structured Streaming for exactly-once event ingestion into Delta Lake.',
      'Optimized checkpoint management and trigger intervals, reducing end-to-end streaming latency by 35%.',
    ],
    metrics: [
      { label: 'Streaming Latency', value: '-35%' },
      { label: 'Delivery Guarantee', value: 'Exactly-Once' },
      { label: 'Processing Type', value: 'Micro-Batch' },
    ],
    flowNodes: [
      {
        id: 'event-producer',
        title: 'Event Producer',
        subtitle: 'IoT / Web Events',
        iconKey: 'producer',
        layer: 'source',
        badgeColor: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10',
        details: {
          format: 'JSON telemetry stream',
          sla: 'Sub-second event emission',
          purpose: 'Live continuous event streams from geospatial & client trackers',
        },
      },
      {
        id: 'event-hub',
        title: 'Azure Event Hub',
        subtitle: 'Message Ingestion',
        iconKey: 'eventhub',
        layer: 'ingest',
        badgeColor: 'border-purple-500/40 text-purple-400 bg-purple-500/10',
        details: {
          engine: 'Azure Event Hubs Standard',
          sla: 'High-throughput partition buffers',
          purpose: 'Decoupled event broker buffering millions of messages',
        },
      },
      {
        id: 'spark-stream',
        title: 'Databricks Streaming',
        subtitle: 'Structured Streaming',
        iconKey: 'databricks',
        layer: 'stream',
        badgeColor: 'border-red-500/40 text-red-400 bg-red-500/10',
        details: {
          engine: 'PySpark Structured Streaming',
          partition: 'Checkpointed micro-batches',
          purpose: 'Windowed aggregations, watermark handling, and anomaly filtering',
        },
      },
      {
        id: 'delta-sink',
        title: 'Delta Lake Sink',
        subtitle: 'ACID Storage',
        iconKey: 'deltalake',
        layer: 'storage',
        badgeColor: 'border-cyan-500/40 text-cyan-400 bg-cyan-500/10',
        details: {
          format: 'Delta tables with write-ahead logs',
          sla: 'Exactly-once semantics',
          purpose: 'High-speed historical log replay & time travel analytics',
        },
      },
      {
        id: 'azure-sql',
        title: 'Azure SQL DB',
        subtitle: 'Live Dashboards',
        iconKey: 'azuresql',
        layer: 'serving',
        badgeColor: 'border-blue-500/40 text-blue-400 bg-blue-500/10',
        details: {
          engine: 'Azure SQL Database',
          purpose: 'Operational serving layer for real-time alerting & dashboards',
        },
      },
    ],
    flowEdges: [
      { label: 'Azure Event Hub ingest' },
      { label: 'Checkpointed micro-batches' },
      { label: 'Exactly-once write' },
      { label: 'Sync to serving DB' },
    ],
  },
];

export const CERTIFICATIONS_LIST: CertificationData[] = [
  {
    name: 'Azure Data Engineer Associate (DP-203)',
    code: 'DP-203',
    issuer: 'Microsoft',
    issueDate: 'Verified Credential',
    status: 'Active',
    credentialUrl:
      'https://learn.microsoft.com/en-us/users/manojgoje-1174/credentials/7faddc6566feb939?ref=https%3A%2F%2Fwww.linkedin.com%2F',
    description:
      'Expertise in data storage, data processing with Azure Synapse and Databricks, data security, and end-to-end data pipeline optimization.',
    iconKey: 'microsoft',
    accentColor: '#0078D4',
  },
  {
    name: 'Databricks Certified Data Engineer Associate',
    code: 'Databricks Associate',
    issuer: 'Databricks',
    issueDate: 'Verified Credential',
    status: 'Active',
    credentialUrl:
      'https://credentials.databricks.com/b7dfc100-9063-481c-a85b-18bb6eeba09b#acc.jukMKAd0',
    description:
      'Proven ability in Apache Spark architecture, PySpark transformations, Delta Lake operations, and automated pipeline orchestration.',
    iconKey: 'databricks',
    accentColor: '#FF3621',
  },
  {
    name: 'Azure Administrator Associate (AZ-104)',
    code: 'AZ-104',
    issuer: 'Microsoft',
    issueDate: 'Verified Credential',
    status: 'Active',
    credentialUrl:
      'https://learn.microsoft.com/api/credentials/share/en-us/GojeManoj-9952/3D6C69F30DFE8FD7?sharingId=D24E8778106DBFCF',
    description:
      'Deep knowledge of Azure identity governance, virtual networking, cloud storage configuration, and resource compute management.',
    iconKey: 'microsoft',
    accentColor: '#00A4EF',
  },
  {
    name: 'Agentic AI Certified Foundations Associate',
    code: 'Oracle 1Z0-1132-24',
    issuer: 'Oracle',
    issueDate: 'Verified Credential',
    status: 'Active',
    credentialUrl:
      'https://catalog-education.oracle.com/pls/certview/sharebadge?id=08CC8C1C7F2B9D660A631B25CFBA02A8B992F6068405E6427632CA4B25A7DA0A',
    description:
      'Foundations of Agentic AI, autonomous agent design, multi-agent frameworks, tool orchestration, and LLM-driven automated workflows.',
    iconKey: 'oracle',
    accentColor: '#F80000',
  },
];

export const EDUCATION_DATA: EducationData = {
  degree: 'Bachelor of Technology (B.Tech)',
  field: 'Computer Science and Engineering',
  institution: 'Shreeyash College of Engineering and Technology',
  location: 'Aurangabad, Maharashtra, India',
  period: 'Aug 2020 – Jul 2024',
  highlights: [
    'Specialized in Database Management Systems (DBMS), Distributed Computing, and Cloud Architectures.',
    'Led technical projects focused on Python data pipelines, geospatial data structures, and algorithmic optimization.',
    'Built foundations in SQL query performance tuning, data structures, and software engineering methodologies.',
  ],
};

export const LEADERSHIP_ACHIEVEMENTS: LeadershipItem[] = [
  {
    id: 'state-team-captain',
    title: 'State-Level Team Leadership & Tournament Semi-Finalist',
    role: 'Team Captain & Lead Strategist',
    metric: 'State Semi-Finals',
    tag: 'Leadership & Team Building',
    iconKey: 'trophy',
    description:
      'Led a 12-player team to the state-level semi-finals, showcasing high-caliber leadership, strategic coordination, crisis management, and team-building skills under high-pressure competitive environments.',
    highlights: [
      'Spearheaded team training schedules, tactical playbook formulations, and real-time on-field decision making.',
      'Fostered collaborative team morale and resilience against elite statewide contenders.',
      'Demonstrated accountability, active delegation, and decisive leadership across multi-stage qualifying rounds.',
    ],
  },
  {
    id: 'coding-competition-coordinator',
    title: 'College-Level Coding Competition Coordinator',
    role: 'Lead Event Organizer & Technical Host',
    metric: '100+ Participants',
    tag: 'Technical Event Coordination',
    iconKey: 'users',
    description:
      'Coordinated a college-level coding competition, ensuring seamless end-to-end event execution, test case verification, automated grading systems, and high participant engagement.',
    highlights: [
      'Curated problem statements spanning data structures, algorithms, and SQL query optimizations.',
      'Managed live judging infrastructure, participant onboarding, and schedule adherence without technical hitches.',
      'Drove cross-departmental outreach, resulting in top attendance and enthusiastic feedback from faculty & peers.',
    ],
  },
  {
    id: 'competitive-programming',
    title: '50+ Coding Competitions & Hackathons Participant',
    role: 'Competitive Programmer & Algorithmic Problem Solver',
    metric: '50+ Contests & Hackathons',
    tag: 'Continuous Learning & Development',
    iconKey: 'code',
    description:
      'Participated in 50+ competitive coding competitions and national hackathons, emphasizing relentless dedication to continuous learning, algorithmic precision, and rapid engineering prototyping.',
    highlights: [
      'Tackled complex algorithmic challenges covering graph theory, dynamic programming, and data engineering.',
      'Engineered rapid full-stack and data prototypes within strict 24-to-48 hour hackathon sprint windows.',
      'Consistently refined problem-solving speed, code cleanliness, and computational complexity optimization.',
    ],
  },
];

